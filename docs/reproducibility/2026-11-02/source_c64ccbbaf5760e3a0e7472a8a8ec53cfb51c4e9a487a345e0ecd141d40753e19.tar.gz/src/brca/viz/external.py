"""Publication figures, tables and narrative from stored external aggregates only."""

from __future__ import annotations

from collections import Counter
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

from brca.viz.coverage import MODEL_STYLE, REFERENCE, _get, _number, _save, _tex

METHODS = {
    "conservative_score_envelope": ("Envelope", "o"),
    "conservative": ("Envelope", "o"),
    "conservative_lower_bound": ("Lower bound", "s"),
    "qin_bootstrap_ridge_cox": ("Qin ridge", "^"),
}
MODELS = {"cox": "Cox", "weibull": "Weibull", "rsf": "RSF", "cox_ridge": "Cox ridge"}
FEATURES = {"clinical": "Clinical", "clinical_molecular": "Clinical + PAM50"}


def _method(name):
    return METHODS.get(name, (name.replace("_", " "), "D"))


def _fmt(value, digits=3):
    return f"{value:.{digits}f}" if _number(value) else "NA"


def _metric_at(model, metric, horizon):
    return next(row for row in model[metric] if row["time_months"] == horizon)


def _ci(summary):
    ci = summary.get("ci")
    return ci if ci and all(_number(value) for value in ci) else None


def _estimate(summary, digits=3):
    point = _fmt(summary.get("estimate"), digits)
    ci = _ci(summary)
    text = (
        f"{point} [{_fmt(ci[0], digits)}, {_fmt(ci[1], digits)}]"
        if ci
        else f"{point} [CI unavailable]"
    )
    if summary.get("failed_replicates", 0):
        requested = summary["valid_replicates"] + summary["failed_replicates"]
        text += f" ({summary['valid_replicates']}/{requested} draws)"
    return text


def _coverage_stat(summary, name):
    return {"estimate": summary.get(name), **summary.get("bootstrap_statistics", {}).get(name, {})}


def _grid(ax, axis="y"):
    ax.grid(axis=axis, linewidth=0.5, color="#dddddd")
    ax.set_axisbelow(True)


def _whisker(ax, position, estimate, ci, color, marker, *, horizontal=False):
    if not _number(estimate):
        return
    if ci:
        if horizontal:
            ax.hlines(position, *ci, color=color, linewidth=1.5)
        else:
            ax.vlines(position, *ci, color=color, linewidth=1.5)
    ax.plot(
        *((estimate, position) if horizontal else (position, estimate)),
        marker=marker,
        color=color,
        markersize=8,
        linestyle="none",
        markeredgecolor="white",
        markeredgewidth=0.8,
    )


def _covariate_figure(report, directory, settings):
    columns = {**report["numeric"], **report["categorical"]}
    names = list(columns)
    fig, axes = plt.subplots(
        1, 2, sharey=True, figsize=(_get(settings, "width_inches"), max(4.5, len(names) * 0.38))
    )
    fig.subplots_adjust(left=0.30, right=0.97, bottom=0.13, top=0.90, wspace=0.38)
    for i, (name, values) in enumerate(columns.items()):
        for key, offset, color, marker in [
            ("source_missing_fraction", -0.12, "#2a78d6", "o"),
            ("target_missing_fraction", 0.12, "#eb6834", "s"),
        ]:
            _whisker(axes[0], i + offset, values[key], None, color, marker, horizontal=True)
        smd = values.get("standardized_mean_difference")
        if _number(smd):
            _whisker(axes[1], i, smd, None, "#2a78d6", "o", horizontal=True)
        else:
            axes[1].text(
                0.02,
                i,
                "categorical" if name in report["categorical"] else "unavailable",
                transform=axes[1].get_yaxis_transform(),
                va="center",
                fontsize=8,
            )
    axes[0].set_yticks(range(len(names)), [name.replace("_", " ") for name in names])
    axes[0].set(xlim=(-0.04, 1.04), ylim=(len(names) - 0.5, -0.5), xlabel="Missing fraction")
    axes[1].set_xlabel("Standardized mean difference\n(TCGA minus METABRIC)")
    axes[1].axvline(0, color=REFERENCE, linewidth=1)
    for ax in axes:
        _grid(ax, "x")
    fig.legend(
        handles=[
            Line2D([], [], marker=marker, color=color, linestyle="none", label=label, markersize=8)
            for label, color, marker in [
                ("METABRIC train", "#2a78d6", "o"),
                ("TCGA", "#eb6834", "s"),
            ]
        ],
        loc="upper center",
        ncol=2,
        frameon=False,
    )
    return _save(fig, directory, "external_covariate_recording_and_shift", settings)


def _performance_figure(report, horizon, directory, settings):
    rows = [(key, _metric_at(model, "uno_c", horizon)) for key, model in report["models"].items()]
    rows.sort(key=lambda pair: pair[1]["estimate"] if _number(pair[1]["estimate"]) else -1)
    fig, ax = plt.subplots(figsize=(_get(settings, "width_inches"), max(4.0, len(rows) * 0.42)))
    fig.subplots_adjust(left=0.38, right=0.97, bottom=0.16, top=0.94)
    labels = []
    for i, (key, metric) in enumerate(rows):
        model, features = key.split("__")
        color, marker = ("#eb6834", "s") if features == "clinical_molecular" else ("#2a78d6", "o")
        _whisker(ax, i, metric["estimate"], _ci(metric), color, marker, horizontal=True)
        labels.append(f"{MODELS.get(model, model)}: {FEATURES[features]}")
        if metric["estimate"] is None:
            ax.text(0.03, i, "unavailable", transform=ax.get_yaxis_transform(), va="center")
        elif metric.get("failed_replicates", 0):
            ax.annotate("*", (metric["estimate"], i), xytext=(6, 5), textcoords="offset points")
    ax.set_yticks(range(len(labels)), labels)
    ax.set(xlim=(0, 1), xlabel=f"Uno concordance through {horizon:g} months (95% bootstrap CI)")
    ax.axvline(0.5, color=REFERENCE, linewidth=1)
    _grid(ax, "x")
    return _save(fig, directory, "external_os_discrimination", settings)


def _coverage_figure(rows, horizon, alpha, directory, settings):
    rows = sorted(rows, key=lambda row: (row["model"], _method(row["method"])[0]))
    fig, axes = plt.subplots(2, 1, sharex=True, figsize=(_get(settings, "width_inches"), 6.1))
    fig.subplots_adjust(left=0.15, right=0.97, bottom=0.18, top=0.88, hspace=0.15)
    labels = []
    for i, row in enumerate(rows):
        summary = row["marginal"]
        color = MODEL_STYLE[row["model"]][1]
        label, marker = _method(row["method"])
        labels.append(f"{MODELS[row['model']]}\n{label}")
        bounds = [
            summary.get("observable_coverage_lower"),
            summary.get("observable_coverage_upper"),
        ]
        if all(_number(value) for value in bounds):
            axes[0].vlines(i, *bounds, color=color, linewidth=6, alpha=0.3)
            axes[0].plot([i, i], bounds, marker="_", linestyle="none", color=color, markersize=8)
        ipcw = _coverage_stat(summary, "ipcw_coverage")
        _whisker(axes[0], i, ipcw["estimate"], _ci(ipcw), color, marker)
        if ipcw["estimate"] is None:
            axes[0].text(i, 0.03, "NA", ha="center", fontsize=8)
        width = _coverage_stat(summary, "width_median_months")
        iqr = [summary.get("width_q25_months"), summary.get("width_q75_months")]
        if all(_number(value) for value in iqr):
            axes[1].vlines(i, *iqr, color=color, linewidth=6, alpha=0.3)
        _whisker(axes[1], i, width["estimate"], _ci(width), color, marker)
    axes[0].axhline(1 - alpha, color=REFERENCE, linewidth=1)
    axes[0].set(ylabel="Coverage", ylim=(-0.02, 1.05))
    axes[1].set(ylabel="Interval width (months)", ylim=(0, horizon * 1.05))
    axes[1].set_xticks(range(len(labels)), labels, rotation=30, ha="right")
    for ax in axes:
        _grid(ax)
    fig.text(
        0.15,
        0.92,
        "Coverage: thick range = observable bounds; symbol / whisker = IPCW / CI.\nWidth: "
        "symbol = median; thick range = IQR; whisker = median CI.",
        fontsize=8,
    )
    return _save(fig, directory, "external_os_coverage_width", settings)


def _shift_figure(rows, scenarios, horizon, alpha, directory, settings):
    rows = sorted(rows, key=lambda row: _method(row["method"])[0])
    fig, axes = plt.subplots(2, 1, sharex=True, figsize=(_get(settings, "width_inches"), 5.8))
    fig.subplots_adjust(left=0.15, right=0.98, bottom=0.15, top=0.81, hspace=0.15)
    colors = ["#2a78d6", "#eb6834", "#1baf7a"]
    legends = []
    for j, row in enumerate(rows):
        label, marker = _method(row["method"])
        color = colors[j % len(colors)]
        legends.append(
            Line2D([], [], color=color, marker=marker, linestyle="none", label=label, markersize=8)
        )
        for i, scenario in enumerate(scenarios):
            values = row["scenarios"][scenario]["estimates"]
            x = i + (j - (len(rows) - 1) / 2) * 0.22
            low, high = values["coverage_lower_bound"], values["coverage_upper_bound"]
            axes[0].vlines(
                x, low["estimate"], high["estimate"], color=color, linewidth=5, alpha=0.3
            )
            for value in [low, high]:
                _whisker(axes[0], x, value["estimate"], _ci(value), color, marker)
            width = values["median_width"]
            _whisker(axes[1], x, width["estimate"], _ci(width), color, marker)
    axes[0].axhline(1 - alpha, color=REFERENCE, linewidth=1)
    axes[0].set(ylabel="Weighted coverage bounds", ylim=(-0.02, 1.05))
    axes[1].set(ylabel="Weighted median width (months)", ylim=(0, horizon * 1.05))
    axes[1].set_xticks(
        range(len(scenarios)), [name.replace("_", " ").capitalize() for name in scenarios]
    )
    fig.legend(handles=legends, loc="upper center", ncol=3, frameon=False)
    fig.text(
        0.15,
        0.86,
        "Coverage: thick range = observable bounds; whiskers = separate bound CIs.\nWidth: "
        "symbol = weighted median; whisker = median CI.",
        fontsize=8,
    )
    for ax in axes:
        _grid(ax)
    return _save(fig, directory, "shift_dss_coverage_width", settings)


def _latex_table(path, labels, statistics, rows):
    """Each statistic gets a decimal-aligned estimate and adjacent uncertainty."""
    columns = "l" * len(labels) + " S[table-format=3.3] l" * len(statistics)
    lines = [
        "% Generated from aggregate JSON; no statistics recomputed.",
        "% Requires booktabs, longtable, siunitx. CI is bootstrap; NA denotes unavailable.",
        r"\begingroup\small\setlength{\tabcolsep}{3pt}",
        r"\begin{longtable}{@{}" + columns + r"@{}}",
        r"\toprule",
        " & ".join(
            [
                *map(_tex, labels),
                *[item for name in statistics for item in ["{" + _tex(name) + "}", "CI"]],
            ]
        )
        + r" \\",
        r"\midrule\endhead",
    ]
    for row_labels, values in rows:
        cells = list(map(_tex, row_labels))
        for value in values:
            point = value.get("estimate")
            cells.append(_fmt(point) if _number(point) else r"\multicolumn{1}{c}{NA}")
            ci = _ci(value)
            rendered = f"[{_fmt(ci[0])}, {_fmt(ci[1])}]" if ci else "NA"
            if value.get("failed_replicates", 0):
                rendered += r"\textsuperscript{*}"
            cells.append(rendered)
        lines.append(" & ".join(cells) + r" \\")
    lines += [
        r"\bottomrule\end{longtable}",
        r"\noindent *At least one undefined bootstrap draw; see JSON/report for counts and "
        r"gate status.",
        r"\endgroup",
        "",
    ]
    path.write_text("\n".join(lines))
    return path


def _tables(inputs, directory):
    paths = []
    for endpoint, report in inputs["performance"].items():
        variants = {"all": report}
        if "complete_predictor_sensitivity" in report:
            variants["complete"] = report["complete_predictor_sensitivity"]
        for variant, values in variants.items():
            for horizon in values["time_grid_months"]:
                rows = []
                for key, model in sorted(values["models"].items()):
                    family, features = key.split("__")
                    rows.append(
                        (
                            [
                                MODELS.get(family, family),
                                "C+P" if features == "clinical_molecular" else "C",
                            ],
                            [
                                _metric_at(model, metric, horizon)
                                for metric in ("uno_c", "brier", "auc")
                            ],
                        )
                    )
                paths.append(
                    _latex_table(
                        directory / f"performance__{endpoint}__{variant}__{horizon:g}.tex",
                        ["Model", "Arm"],
                        ["Uno C", "Brier", "AUC"],
                        rows,
                    )
                )
            paths.append(
                _latex_table(
                    directory / f"ibs__{endpoint}__{variant}.tex",
                    ["Model", "Arm"],
                    ["IBS"],
                    [
                        (
                            [
                                key.split("__")[0],
                                "C+P" if key.endswith("__clinical_molecular") else "C",
                            ],
                            [value["ibs"]],
                        )
                        for key, value in sorted(values["models"].items())
                    ],
                )
            )
    contexts = sorted(
        {
            (row["endpoint"], row["horizon_months"], row["feature_set"])
            for row in inputs["coverage"].values()
        }
    )
    for endpoint, horizon, features in contexts:
        selected = sorted(
            (
                row
                for row in inputs["coverage"].values()
                if (row["endpoint"], row["horizon_months"], row["feature_set"])
                == (endpoint, horizon, features)
            ),
            key=lambda row: (row["alpha"], row["model"], row["method"]),
        )
        for name, statistics in [
            (
                "coverage",
                ["observable_coverage_lower", "observable_coverage_upper", "ipcw_coverage"],
            ),
            ("width", ["width_median_months", "full_support_fraction"]),
        ]:
            rows = [
                (
                    [MODELS[row["model"]], _method(row["method"])[0], f"{1 - row['alpha']:.0%}"],
                    [_coverage_stat(row["marginal"], stat) for stat in statistics],
                )
                for row in selected
            ]
            names = (
                ["Lower", "Upper", "IPCW"]
                if name == "coverage"
                else ["Median (months)", "Full support"]
            )
            paths.append(
                _latex_table(
                    directory / f"{name}__{endpoint}__{features}__{horizon:g}.tex",
                    ["Model", "Method", "Nominal"],
                    names,
                    rows,
                )
            )
    return paths


def _performance_markdown(report):
    lines = [
        "| Model / predictors | Horizon (months) | Uno C [CI] | Brier [CI] | AUC [CI] |",
        "| --- | ---: | --- | --- | --- |",
    ]
    for key, model in sorted(report["models"].items()):
        for horizon in report["time_grid_months"]:
            lines.append(
                f"| {key} | {horizon:g} | "
                + " | ".join(
                    _estimate(_metric_at(model, metric, horizon))
                    for metric in ("uno_c", "brier", "auc")
                )
                + " |"
            )
    lines += [
        "",
        "IBS uses exactly the prespecified integration grid; it is unavailable if any grid "
        "point is unsupported.",
        "",
    ]
    lines.extend(
        f"- {key}: IBS {_estimate(model['ibs'])}."
        for key, model in sorted(report["models"].items())
    )
    paired = report.get("paired_feature_comparisons", {})
    if paired:
        lines += [
            "",
            "Paired differences: clinical + PAM50 minus clinical, using the same target "
            "patients and bootstrap selections. Positive Uno C/AUC differences and "
            "negative Brier/IBS differences favor the molecular arm. An interval crossing "
            "zero does not establish an improvement; comparisons remain exploratory and "
            "are not adjusted for multiplicity.",
            "",
            "| Model | Horizon (months) | Delta Uno C [CI] | Delta Brier [CI] | Delta AUC [CI] |",
            "| --- | ---: | --- | --- | --- |",
        ]
        for key, comparison in sorted(paired.items()):
            for horizon in report["time_grid_months"]:
                lines.append(
                    f"| {MODELS.get(key, key)} | {horizon:g} | "
                    + " | ".join(
                        _estimate(_metric_at(comparison, metric, horizon))
                        for metric in ("uno_c", "brier", "auc")
                    )
                    + " |"
                )
        lines += ["", "Paired IBS differences over the same complete prespecified grid:", ""]
        lines.extend(
            f"- {MODELS.get(key, key)}: delta IBS {_estimate(comparison['ibs'])}."
            for key, comparison in sorted(paired.items())
        )
    return lines


def build_external_report(inputs):
    """Generate reproducible narrative and tables, without touching patient data."""
    settings, audit = inputs["plan"]["settings"], inputs["cohort_audit"]
    external, shifted = settings["external_validation"], settings["distribution_shift"]
    preparation = inputs["preparation"]
    lines = [
        "# External validation and distribution-shift extension",
        "",
        "This report is generated exclusively from saved aggregate JSON. External "
        "validation is exploratory; the internal shift experiment reuses the previously "
        "evaluated METABRIC test patients.",
        "",
        "## Design and interpretation",
        "",
        "The external experiment fits new common-predictor models on the original METABRIC "
        "training patients and calibrates intervals on the original METABRIC calibration "
        "patients. Predictors are age, ER, PR and HER2, with PAM50 added in the molecular "
        "arm. These are different fits from the original full clinical models: unavailable "
        "tumour size, grade and comparable node information are not fabricated or "
        "substituted.",
        "",
        "TCGA overall survival is the principal external endpoint. Its disease-specific "
        "endpoint is an exploratory death-with-tumour proxy and does not reproduce "
        "METABRIC's recorded breast-cancer-specific death endpoint. TCGA's shorter "
        "follow-up limits the supported evaluation horizons; unsupported horizons remain "
        "explicit rather than being replaced after evaluation.",
        "",
        "Target-cohort reverse Kaplan-Meier censoring weights are evaluation nuisance "
        "estimates. They are reestimated in each ordinary paired patient bootstrap; "
        "predictive models and conformal calibration are never refitted using TCGA "
        "outcomes. IPCW assumes independent censoring and sufficient support in TCGA. "
        "Source conformal guarantees do not automatically transport under distribution "
        "shift.",
        "",
        f"Support gates: at least {external['minimum_events']} events by a metric horizon, "
        f"{external['minimum_at_risk']} patients with follow-up support, and censoring "
        f"survival at least {external['minimum_censoring_survival']:.2f}. Confidence "
        f"level: {external['confidence_level']:.0%}; requested patient bootstraps: "
        f"{external['bootstrap_replicates']}; minimum successful fraction: "
        f"{external['minimum_success_fraction']:.0%}.",
        "",
        "Observable lower/upper coverage bounds reflect censoring uncertainty, not "
        "confidence limits for the unknown latent coverage. Bootstrap CIs for each bound "
        "describe sampling uncertainty separately. Lower-bound intervals answer a "
        "one-sided question; comparisons to two-sided envelope/Qin intervals must retain "
        "that distinction. Width accompanies every coverage comparison.",
        "",
        f"Source training patients: {preparation.get('n_train', 'NA')}; score-calibration "
        f"patients: {preparation.get('n_cal', 'NA')}. Qin uses training bootstrap pivots. "
        "Its stored n_cal field counts pivots, not calibration patients; it is not "
        "comparable to the patient calibration count of the score-envelope methods.",
        "",
        "## Cohort and recording compatibility",
        "",
        "| Endpoint | Patients | Events | Reverse-KM median follow-up (months) | Complete "
        "common predictors |",
        "| --- | ---: | ---: | ---: | ---: |",
    ]
    for endpoint, values in audit.get("outcome_summaries", {}).items():
        lines.append(
            f"| {endpoint} | {values['n']} | {values['events']} | "
            f"{_fmt(values['reverse_km_median_followup_months'], 1)} | "
            f"{values.get('n_complete_common_predictors', 'NA')} |"
        )
    lines += [
        "",
        "Eligibility and endpoint exclusions are recorded sequentially in "
        "[cohort_audit.json](cohort_audit.json). Missing common predictors use "
        "preprocessing fitted on METABRIC training patients; unknown receptor/PAM50 levels "
        "remain explicit.",
        "",
    ]
    for note in ["positive_nodes_note", "tumour_size_note", "subtype_note"]:
        if note in audit:
            lines += [audit[note], ""]
    lines += [
        "| Endpoint / predictor | Source missing fraction | Target missing fraction | "
        "Numeric SMD / categorical total variation |",
        "| --- | ---: | ---: | ---: |",
    ]
    for endpoint, shift in inputs["covariate_shift"].items():
        for kind in ["numeric", "categorical"]:
            for name, values in shift[kind].items():
                distance = (
                    values.get("standardized_mean_difference")
                    if kind == "numeric"
                    else values["total_variation_distance"]
                )
                lines.append(
                    f"| {endpoint} / {name} | {_fmt(values['source_missing_fraction'])} | "
                    f"{_fmt(values['target_missing_fraction'])} | {_fmt(distance)} |"
                )
    lines += [
        "",
        "SMD is signed (target minus source); total variation includes missingness and has "
        "a different scale. These descriptions do not establish which mechanisms changed "
        "or identify a causal explanation.",
        "",
        "![Covariate recording and shift](figures/external_covariate_recording_and_shift.png)",
        "",
        "## External predictive performance",
        "",
    ]
    for endpoint, report in inputs["performance"].items():
        lines += [f"### {endpoint}", "", "Prespecified support:", ""]
        for support in report["support"]:
            lines.append(
                f"- {support['time_months']:g} months: "
                f"events={support['n_events_by_horizon']}, at risk={support['n_at_risk']}, "
                f"G={_fmt(support['censoring_survival'])}; "
                + ("supported." if support["supported"] else ", ".join(support["reasons"]) + ".")
            )
        lines += ["", *_performance_markdown(report), ""]
        if "complete_predictor_sensitivity" in report:
            complete = report["complete_predictor_sensitivity"]
            lines += [
                f"#### Complete-predictor sensitivity (n={complete['n_target']})",
                "",
                "The same frozen predictions are evaluated on patients with every common "
                "predictor recorded. This changes the evaluated population and may "
                "introduce selection differences; models are not refitted.",
                "",
                *_performance_markdown(complete),
                "",
            ]
    lines += [
        "![OS discrimination](figures/external_os_discrimination.png)",
        "",
        "## External interval coverage and width",
        "",
        f"The table displays the prespecified {1 - external['report_alpha']:.0%} nominal "
        f"level. LaTeX tables and [coverage.json](coverage.json) retain every 80/90/95% "
        f"level and all interval horizons.",
        "",
        "| Endpoint | Horizon | Model / predictors / method | Observable bounds | IPCW "
        "[CI] | Median width in months [CI] |",
        "| --- | ---: | --- | --- | --- | --- |",
    ]
    suppressed, subgroup_unavailable = 0, 0
    for row in sorted(
        inputs["coverage"].values(),
        key=lambda row: (
            row["endpoint"],
            row["horizon_months"],
            row["model"],
            row["feature_set"],
            row["method"],
            row["alpha"],
        ),
    ):
        for groups in row.get("subgroups", {}).values():
            for summary in groups.values():
                suppressed += summary.get("status") == "suppressed_small_group"
                subgroup_unavailable += summary.get("ipcw_status") == "unavailable"
        if row["alpha"] != external["report_alpha"]:
            continue
        summary = row["marginal"]
        bounds = (
            f"[{_fmt(summary['observable_coverage_lower'])}, "
            f"{_fmt(summary['observable_coverage_upper'])}]"
        )
        lines.append(
            f"| {row['endpoint']} | {row['horizon_months']:g} | {row['model']} / "
            f"{row['feature_set']} / {_method(row['method'])[0]} | {bounds} | "
            f"{_estimate(_coverage_stat(summary, 'ipcw_coverage'))} | "
            f"{_estimate(_coverage_stat(summary, 'width_median_months'), 1)} |"
        )
    lines += [
        "",
        "![OS coverage and width](figures/external_os_coverage_width.png)",
        "",
        "The interval figure uses clinical + PAM50 at the prespecified OS horizon. Thick "
        "coverage ranges show observable bounds; symbols/whiskers show IPCW estimates/CIs "
        "where supported. NA identifies absent IPCW support. Width symbols, thick ranges "
        "and whiskers show median, IQR and median CI respectively.",
        "",
        f"Subgroup results remain in coverage.json: {suppressed} repeated "
        f"interval-by-subgroup cells are suppressed for small groups and "
        f"{subgroup_unavailable} retained cells have unavailable IPCW coverage. These are "
        f"cell counts, not counts of distinct patients or subgroups. Passing marginal "
        f"support does not imply subtype-specific support or coverage. No multiplicity "
        f"adjustment is applied.",
        "",
        "## Covariate-shift stress test",
        "",
        "The source test cohort is reweighted under fixed younger, older and "
        "Basal-enriched scenarios. Numeric tilt location/scale comes from training "
        "patients. This evaluates fixed intervals under hypothetical changes in case mix; "
        "it performs no weighted conformal calibration, adds no new patients and supplies "
        "no restored coverage guarantee.",
        "",
        f"The display model was fixed as Cox with clinical + PAM50, DSS, "
        f"{shifted['report_horizon_months']:g} months, {1 - shifted['report_alpha']:.0%} "
        f"nominal coverage. It was not chosen from the observed results. All families, "
        f"endpoints, methods, alpha levels and horizons remain in "
        f"[distribution_shift.json](distribution_shift.json).",
        "",
        "| Method | Scenario | Effective sample size | Lower bound [CI] | Upper bound [CI] "
        "| Median width in months [CI] |",
        "| --- | --- | ---: | --- | --- | --- |",
    ]
    for row in _display_shift_rows(inputs):
        for scenario, summary in row["scenarios"].items():
            estimates = summary["estimates"]
            lines.append(
                f"| {_method(row['method'])[0]} | {scenario} | "
                f"{_fmt(summary['effective_sample_size'], 1)} | "
                f"{_estimate(estimates['coverage_lower_bound'])} | "
                f"{_estimate(estimates['coverage_upper_bound'])} | "
                f"{_estimate(estimates['median_width'], 1)} |"
            )
    lines += [
        "",
        "![Shift coverage and width](figures/shift_dss_coverage_width.png)",
        "",
        "## Bootstrap and inference qualifications",
        "",
        "Every estimate retains its bootstrap status in JSON. A missing CI can mean the "
        "original estimate is unsupported or that too few bootstrap samples were defined; "
        "it is not evidence of zero uncertainty. CIs retaining some failed samples are "
        "conditional on successful samples and approximate. External CIs include target "
        "censoring-estimation uncertainty, but condition on source fits and calibration. "
        "Internal shift CIs condition on the source fits, calibration and specified tilt "
        "weights and retain the original test split strata.",
        "",
        "This extension does not establish clinical utility, solve endpoint "
        "incompatibility, or demonstrate conditional outcome transport. The common-feature "
        "comparison cannot be interpreted as a direct change from the original "
        "full-feature METABRIC performance. The internal shift analysis remains post hoc "
        "because its patients were already evaluated. Source/artifact hashes verify "
        "provenance; they do not replace an independent clean-commit numerical "
        "reproduction.",
        "",
    ]
    for name in ["performance", "coverage", "distribution_shift"]:
        counts = _status_counts(inputs[name])
        lines.append(
            f"- {name} stored statistic statuses: "
            + "; ".join(f"{status}={count}" for status, count in sorted(counts.items()))
            + "."
        )
    lines += ["", "## Source model diagnostics", ""]
    for key, model in sorted(preparation.get("models", {}).items()):
        if model.get("model") == "weibull":
            diagnostic = model["diagnostics"]
            lines.append(
                f"- {key}: MCMC gate passed={diagnostic.get('passed')}; "
                f"max R-hat={_fmt(diagnostic.get('max_rhat'))}; "
                f"minimum bulk ESS={_fmt(diagnostic.get('min_ess_bulk'), 1)}; "
                f"minimum tail ESS={_fmt(diagnostic.get('min_ess_tail'), 1)}; "
                f"divergences={diagnostic.get('divergences', 'NA')}."
            )
        elif model.get("model") == "cox":
            diagnostic = model["diagnostics"]
            global_test = diagnostic.get("global", {})
            p_value = global_test.get("p_value")
            p_text = f"{p_value:.3g}" if _number(p_value) else "NA"
            lines.append(
                f"- {key}: proportional-hazards departure flagged="
                f"{global_test.get('flagged', 'NA')}; global p={p_text}; "
                "a working-model diagnostic does not establish external validity."
            )
    lines += [
        "",
        "Passing MCMC diagnostics assesses sampling; it does not establish distributional "
        "adequacy or external validity. Full source model and Qin refit diagnostics remain "
        "in the preparation artifact.",
        "",
    ]
    if preparation.get("ridge"):
        lines += [
            "## Qin bootstrap support",
            "",
            "| Source endpoint / feature arm | Successful / requested refits | Event-pool ESS |",
            "| --- | ---: | ---: |",
        ]
        for key, item in sorted(preparation["ridge"].items()):
            diagnostic = item["diagnostics"]
            lines.append(
                f"| {key} | {diagnostic['bootstrap_successful']} / "
                f"{diagnostic['bootstrap_requested']} | "
                f"{_fmt(diagnostic.get('event_pool_effective_sample_size'), 1)} |"
            )
        lines += [
            "",
            "Successful ridge refits address numerical instability. A small "
            "inverse-censoring-weighted event-pool effective sample size still limits "
            "the information behind Qin's bootstrap pivots, especially for DSS.",
            "",
        ]
    return "\n".join(lines)


def _status_counts(value):
    counts = Counter()
    if isinstance(value, dict):
        if "estimate" in value and "status" in value:
            counts[value["status"]] += 1
        for item in value.values():
            counts.update(_status_counts(item))
    elif isinstance(value, list):
        for item in value:
            counts.update(_status_counts(item))
    return counts


def _display_shift_rows(inputs):
    cfg = inputs["plan"]["settings"]["distribution_shift"]
    return [
        row
        for row in inputs["distribution_shift"]["results"].values()
        if row["endpoint"] == "disease_specific"
        and row["model"] == "cox"
        and row["feature_set"] == "clinical_molecular"
        and row["alpha"] == cfg["report_alpha"]
        and row["horizon_months"] == cfg["report_horizon_months"]
    ]


def render_external_validation(inputs, output_dir: Path, config):
    directory = Path(output_dir)
    figures, tables = directory / "figures", directory / "tables"
    figures.mkdir(parents=True, exist_ok=True)
    tables.mkdir(parents=True, exist_ok=True)
    settings = _get(config, "figures")
    ext = inputs["plan"]["settings"]["external_validation"]
    shift = inputs["plan"]["settings"]["distribution_shift"]
    endpoint, horizon, alpha = (
        ext["primary_external_endpoint"],
        ext["primary_external_horizon_months"],
        ext["report_alpha"],
    )
    coverage = [
        row
        for row in inputs["coverage"].values()
        if row["endpoint"] == endpoint
        and row["horizon_months"] == horizon
        and row["alpha"] == alpha
        and row["feature_set"] == "clinical_molecular"
    ]
    paths = []
    with plt.rc_context(
        {
            "font.size": max(8, _get(settings, "font_size")),
            "axes.spines.top": False,
            "axes.spines.right": False,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    ):
        paths.extend(_covariate_figure(inputs["covariate_shift"][endpoint], figures, settings))
        paths.extend(
            _performance_figure(inputs["performance"][endpoint], horizon, figures, settings)
        )
        paths.extend(_coverage_figure(coverage, horizon, alpha, figures, settings))
        paths.extend(
            _shift_figure(
                _display_shift_rows(inputs),
                list(inputs["distribution_shift"]["scenarios"]),
                shift["report_horizon_months"],
                shift["report_alpha"],
                figures,
                settings,
            )
        )
    paths.extend(_tables(inputs, tables))
    report = directory / "report.md"
    report.write_text(build_external_report(inputs))
    paths.append(report)
    return paths
