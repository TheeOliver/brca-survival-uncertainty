"""Isolated TCGA transport experiment and post hoc covariate-shift stress tests.

Source models use only the original METABRIC training partition. Conformal score
envelopes use only its calibration partition. TCGA outcomes estimate evaluation
censoring nuisances, never a predictive model or a conformal calibration rule.
The stage-05 caller alone opens the original test cache.
"""

from __future__ import annotations

import copy
import json
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import yaml
from sksurv.nonparametric import kaplan_meier_estimator
from sksurv.util import Surv

from brca.calibration import interval_key, load_calibration, model_quantiles
from brca.config import PROJECT_ROOT
from brca.conformal.lower import LowerBoundCalibration, calibrate_lower_bound
from brca.conformal.qin import QinBootstrap, predict_qin_intervals
from brca.conformal.qin_ridge import bootstrap_ridge_cox_pivots, fit_qin_ridge_model
from brca.conformal.survival import ConformalCalibration, calibrate_intervals
from brca.data.eda import outcome_labels
from brca.data.partitions import load_partition
from brca.data.preprocessing import TrainingPreprocessor
from brca.fitting import MODEL_TYPES, load_fit
from brca.manifest import sha256_file, write_json_exclusive
from brca.models.bayesian import BayesianAFTModel
from brca.models.cox import CoxPHModel
from brca.pipeline import named_rng, write_json


def extension_directory(run):
    return run.outputs / "external_validation"


def _verify_hashes(hashes):
    if any(not Path(p).is_file() or sha256_file(p) != h for p, h in hashes.items()):
        raise ValueError("An extension input or prepared artifact changed")


def freeze_extension_plan(run, index, settings_path):
    """Freeze all analysis choices before extension fitting or outcome evaluation."""
    settings_path = Path(settings_path).resolve()
    settings = yaml.safe_load(settings_path.read_text())
    cfg = settings["external_validation"]
    if (
        cfg["clinical_features"] != ["age_at_diagnosis", "er_status", "pr_status", "her2_status"]
        or cfg["molecular_features"] != ["pam50_subtype"]
        or set(cfg["endpoints"]) != {"overall", "disease_specific"}
        or not cfg["female_only"]
        or cfg["include_nodes"]
        or cfg["her2_rule"] != "ihc_then_fish"
    ):
        raise ValueError("Unreviewed TCGA harmonization or feature protocol")
    original = json.loads((run.outputs / "evaluation/plan.json").read_text())
    calibration = load_calibration(run, index)
    bindings = {
        str(run.outputs / "models/fit_index.json"): original["fit_index_sha256"],
        str(run.outputs / "models/conformal_calibration.json"): original["calibration_sha256"],
        str(run.outputs / "evaluation/test_cache.pkl"): original["test_cache_sha256"],
        str(run.processed / "partitions/train.csv"): index["training_sha256"],
        str(run.processed / "partitions/calibration.csv"): calibration[
            "calibration_partition_sha256"
        ],
        str(run.processed / "splits.json"): index["split_sha256"],
    }
    _verify_hashes(bindings)
    # The completed reliability comparator is reused as-is in the stress test.
    reliability = run.outputs / "uncertainty_reliability"
    reliability_state = json.loads((reliability / "preparation.json").read_text())
    rb = json.loads((reliability / "preparation_binding.json").read_text())
    if rb["preparation_sha256"] != sha256_file(reliability / "preparation.json") or rb[
        "plan_sha256"
    ] != sha256_file(reliability / "plan.json"):
        raise ValueError("Historical reliability preparation changed")
    bindings.update(reliability_state["artifacts_sha256"])
    for path in [
        run.outputs / "evaluation/plan.json",
        reliability / "preparation.json",
        reliability / "preparation_binding.json",
        reliability / "plan.json",
        run.outputs / "metrics/performance.json",
        run.outputs / "metrics/conformal_coverage.json",
    ]:
        bindings[str(path)] = sha256_file(path)
    _verify_hashes(bindings)
    raw_hashes = {}
    for source in cfg["sources"].values():
        directory = PROJECT_ROOT / settings["paths"]["raw"] / source["raw_subdir"]
        for name in (
            "study.json.gz",
            "clinical_attributes.json.gz",
            "clinical_patient.json.gz",
            "clinical_sample.json.gz",
            "PROVENANCE.json",
        ):
            path = directory / name
            raw_hashes[str(path)] = sha256_file(path)
    sources = [PROJECT_ROOT / "scripts/05_evaluate.py", PROJECT_ROOT / "scripts/download_tcga.py"]
    sources += sorted((PROJECT_ROOT / "src/brca").rglob("*.py"))
    sources = [p for p in sources if "viz" not in p.parts and p.name != "reporting.py"]
    protocol = {
        "schema_version": 1,
        "status": "exploratory_external_validation_and_post_hoc_internal_shift",
        "settings": settings,
        "settings_sha256": sha256_file(settings_path),
        "config_sha256": run.metadata["config_sha256"],
        "lock_sha256": sha256_file(PROJECT_ROOT / "uv.lock"),
        "source_sha256": {str(p.relative_to(PROJECT_ROOT)): sha256_file(p) for p in sources},
        "frozen_inputs_sha256": bindings,
        "raw_inputs_sha256": raw_hashes,
        "external_scope": "new_common_feature_models_fitted_on_original_METABRIC_train",
        "external_censoring": "target_reverse_KM_reestimated_in_paired_patient_bootstrap",
        "dss_caveat": "TCGA_death_with_tumor_proxy_differs_from_METABRIC_cause_specific_death",
        "shift_scope": "fixed_density_tilts_of_previously_evaluated_test_patients",
        "conformal_guarantee_under_shift": False,
    }
    path = extension_directory(run) / "plan.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if json.loads(path.read_text()) != protocol:
            raise ValueError(
                "Extension plan or source changed; do not overwrite an opened analysis"
            )
    else:
        write_json_exclusive(path, protocol)
    return settings


def common_feature_config(config, settings):
    cfg = copy.deepcopy(config)
    cfg.feature_sets.clinical = list(settings["clinical_features"])
    cfg.feature_sets.clinical_molecular = list(settings["molecular_features"])
    return cfg


def prepare_external_models(run, settings):
    """Fit on original train, calibrate on original calibration; never load TCGA."""
    directory = extension_directory(run)
    state_path = directory / "preparation.json"
    plan_hash = sha256_file(directory / "plan.json")
    state = {
        "plan_sha256": plan_hash,
        "models": {},
        "preprocessors": {},
        "calibration": {},
        "ridge": {},
        "artifacts_sha256": {},
        "complete": False,
    }
    if state_path.exists():
        state = json.loads(state_path.read_text())
        if state["plan_sha256"] != plan_hash:
            raise ValueError("Prepared models belong to another extension plan")
        _verify_hashes(state["artifacts_sha256"])
        if state["complete"]:
            _verify_preparation(directory)
            return state
    ext = settings["external_validation"]
    cfg = common_feature_config(run.config, ext)
    train = load_partition(run.config, "train")
    calibration = load_partition(run.config, "calibration")
    model_dir = directory / "models"
    model_dir.mkdir(exist_ok=True)
    for feature in ("clinical", "clinical_molecular"):
        path = model_dir / f"preprocessor__{feature}.pkl"
        if feature in state["preprocessors"]:
            pre = TrainingPreprocessor.load(path)
        else:
            pre = TrainingPreprocessor(cfg, feature).fit(train)
            pre.save(path)
            state["preprocessors"][feature] = str(path)
            state["artifacts_sha256"][str(path)] = sha256_file(path)
            write_json(state_path, state)
        X_train, X_cal = pre.transform(train), pre.transform(calibration)
        for endpoint in ext["endpoints"]:
            y_train, y_cal = outcome_labels(train, endpoint), outcome_labels(calibration, endpoint)
            for name in MODEL_TYPES:
                key = f"{endpoint}__{name}__{feature}"
                if key in state["models"]:
                    continue
                rng = named_rng(cfg.seed, "external_common_fit", key)
                model = (
                    BayesianAFTModel(cfg, rng)
                    if name == "weibull"
                    else MODEL_TYPES[name](getattr(cfg, name), rng=rng)
                )
                print(f"External common-feature training: {key}", flush=True)
                model.fit(X_train, y_train)
                path = model_dir / f"{key}{'.nc' if name == 'weibull' else '.pkl'}"
                model.save(path)
                artifacts = [path] + ([path.with_suffix(".json")] if name == "weibull" else [])
                diagnostics = (
                    model.diagnostics_
                    if name == "weibull"
                    else model.ph_diagnostic_
                    if name == "cox"
                    else {"untuned": True}
                )
                record = {
                    "endpoint": endpoint,
                    "feature_set": feature,
                    "model": name,
                    "path": str(path),
                    "diagnostics": diagnostics,
                    "artifacts_sha256": {str(p): sha256_file(p) for p in artifacts},
                }
                quantiles = model_quantiles(model, X_cal, ext["alphas"])
                lower_quantiles = model.predict_quantiles(X_cal, np.array(ext["alphas"]))
                for a, alpha in enumerate(ext["alphas"]):
                    for horizon in ext["interval_horizons_months"]:
                        low, high = np.minimum(quantiles[alpha], horizon).T
                        fitted = calibrate_intervals(
                            y_cal,
                            low,
                            high,
                            alpha,
                            horizon=horizon,
                            strata=calibration["event"].to_numpy(bool),
                            expected_strata=(False, True),
                        )
                        lower = calibrate_lower_bound(
                            y_cal,
                            lower_quantiles[:, a],
                            alpha,
                            horizon=horizon,
                            strata=calibration["event"].to_numpy(bool),
                            expected_strata=(False, True),
                        )
                        for method, result in [
                            ("conservative", fitted),
                            ("conservative_lower_bound", lower),
                        ]:
                            state["calibration"][interval_key(key, alpha, horizon, method)] = {
                                "model_key": key,
                                "method": method,
                                "calibration": result.to_dict(),
                            }
                state["models"][key] = record
                state["artifacts_sha256"].update(record["artifacts_sha256"])
                write_json(state_path, state)
            key = f"{endpoint}__cox__{feature}"
            if key not in state["ridge"]:
                ridge_cfg = SimpleNamespace(**{**vars(cfg.cox), "alpha": ext["qin_ridge_alpha"]})
                model = fit_qin_ridge_model(
                    X_train, y_train, ridge_cfg, rng=named_rng(cfg.seed, "external_ridge", key)
                )
                bootstrap = bootstrap_ridge_cox_pivots(
                    X_train,
                    y_train,
                    model,
                    ridge_cfg,
                    replicates=ext["qin_bootstrap_replicates"],
                    minimum_censoring_survival=ext["qin_minimum_censoring_survival"],
                    rng=named_rng(cfg.seed, "external_qin", key),
                )
                path = model_dir / f"ridge__{key}.pkl"
                model.save(path)
                state["ridge"][key] = {
                    "path": str(path),
                    "pivots": bootstrap.pivots.tolist(),
                    "diagnostics": bootstrap.diagnostics,
                }
                state["artifacts_sha256"][str(path)] = sha256_file(path)
                write_json(state_path, state)
                print(f"External Qin bootstrap: {key}, all refits passed", flush=True)
    state.update(complete=True, n_train=len(train), n_cal=len(calibration))
    write_json(state_path, state)
    write_json(
        directory / "preparation_binding.json",
        {"plan_sha256": plan_hash, "preparation_sha256": sha256_file(state_path)},
    )
    return state


def _verify_preparation(directory):
    binding = json.loads((directory / "preparation_binding.json").read_text())
    if binding["plan_sha256"] != sha256_file(directory / "plan.json") or binding[
        "preparation_sha256"
    ] != sha256_file(directory / "preparation.json"):
        raise ValueError("Prepared calibration or bootstrap state changed")


def _seed(run, *names):
    return int(named_rng(run.config.seed, *names).integers(0, np.iinfo(np.uint32).max))


def shift_reporting_frame(frame, unknown_category):
    """Unify missing-category coding for descriptive diagnostics only."""
    return frame.replace(unknown_category, np.nan)


def _intervals_for_model(model, X, key, states, alphas, horizons, ridge=None):
    quantiles = model_quantiles(model, X, alphas)
    low_quantiles = model.predict_quantiles(X, np.array(alphas))
    for a, alpha in enumerate(alphas):
        for horizon in horizons:
            k = interval_key(key, alpha, horizon, "conservative")
            params = states[k]["calibration"]
            yield (
                k,
                ConformalCalibration.from_dict(params).predict(
                    *np.minimum(quantiles[alpha], horizon).T
                ),
            )
            k = interval_key(key, alpha, horizon, "conservative_lower_bound")
            if k in states:
                yield (
                    k,
                    LowerBoundCalibration.from_dict(states[k]["calibration"]).predict(
                        low_quantiles[:, a]
                    ),
                )
            if ridge is not None:
                ridge_model, bootstrap = ridge
                k = interval_key(key, alpha, horizon, "qin_bootstrap_ridge_cox")
                yield (
                    k,
                    replace(
                        predict_qin_intervals(
                            ridge_model, X, bootstrap, alpha=alpha, horizon=horizon
                        ),
                        method="qin_bootstrap_ridge_cox",
                    ),
                )


def run_shift_analysis(run, index, settings, test):
    from brca.evaluation.shift import shift_weights, weighted_interval_report

    cfg, directory = settings["distribution_shift"], extension_directory(run)
    train = load_partition(run.config, "train")
    states = load_calibration(run, index)["states"]
    reliability = json.loads((run.outputs / "uncertainty_reliability/preparation.json").read_text())
    states = {**states, **reliability["lower_states"]}
    weights = {
        name: shift_weights(train, test, scenario) for name, scenario in cfg["scenarios"].items()
    }
    results = {}
    for key, record in index["models"].items():
        model = load_fit(record)
        pre = TrainingPreprocessor.load(Path(index["preprocessors"][record["feature_set"]]))
        X = pre.transform(test)
        ridge = None
        if key in reliability["ridge"]:
            item = reliability["ridge"][key]
            ridge = (
                CoxPHModel.load(item["path"]),
                QinBootstrap(np.array(item["pivots"]), item["diagnostics"]),
            )
        for cell, intervals in _intervals_for_model(
            model, X, key, states, cfg["alphas"], cfg["horizons_months"], ridge
        ):
            results[cell] = {
                "endpoint": record["endpoint"],
                "model": record["model"],
                "feature_set": record["feature_set"],
                "method": intervals.method,
                "alpha": intervals.alpha,
                "horizon_months": intervals.horizon,
                "scenarios": {
                    name: weighted_interval_report(
                        outcome_labels(test, record["endpoint"]),
                        intervals,
                        w,
                        bootstrap_replicates=cfg["bootstrap_replicates"],
                        seed=_seed(run, "shift_bootstrap"),
                        confidence_level=cfg["confidence_level"],
                        minimum_success_fraction=cfg["minimum_success_fraction"],
                        bootstrap_strata=test["event"].to_numpy(bool),
                    )
                    for name, w in weights.items()
                },
            }
        print(f"Frozen-model shift evaluated: {key}", flush=True)
    output = {
        "status": "post_hoc_test_reuse",
        "n_original_test": len(test),
        "scenarios": cfg["scenarios"],
        "coverage_guarantee_under_shift": False,
        "interpretation": (
            "Weighted target-population summaries; no new independent patients or recalibration"
        ),
        "results": results,
    }
    write_json(directory / "distribution_shift.json", output)
    return directory / "distribution_shift.json"


def evaluate_external(run, settings, state):
    from brca.data.tcga import load_tcga_snapshot, prepare_tcga
    from brca.evaluation.external import (
        external_coverage,
        external_metrics,
        prepare_external_coverage_bootstrap,
    )
    from brca.evaluation.shift import covariate_shift_report

    cfg, directory = settings["external_validation"], extension_directory(run)
    _verify_preparation(directory)
    snapshots = {
        name: load_tcga_snapshot(
            PROJECT_ROOT / settings["paths"]["raw"] / spec["raw_subdir"], spec["study_id"]
        )
        for name, spec in cfg["sources"].items()
    }
    cohorts, audit = prepare_tcga(
        snapshots["pancan"],
        snapshots["legacy"],
        female_only=cfg["female_only"],
        her2_rule=cfg["her2_rule"],
    )
    train = load_partition(run.config, "train")
    # Raw and model bytes must still match the protocol after preparation.
    plan = json.loads((directory / "plan.json").read_text())
    _verify_hashes(plan["raw_inputs_sha256"])
    _verify_hashes(state["artifacts_sha256"])
    performance, coverage, shift = {}, {}, {}
    evaluation_args = {
        "bootstrap_replicates": cfg["bootstrap_replicates"],
        "confidence_level": cfg["confidence_level"],
        "min_censoring_survival": cfg["minimum_censoring_survival"],
        "minimum_success_fraction": cfg["minimum_success_fraction"],
        "minimum_events": cfg["minimum_events"],
        "minimum_at_risk": cfg["minimum_at_risk"],
    }
    for endpoint in cfg["endpoints"]:
        cohort = cohorts[endpoint]
        if set(cohort.patient_id) & set(train.patient_id):
            raise ValueError("Source and external cohort identifiers overlap")
        y = Surv.from_arrays(
            cohort["event"].to_numpy(bool), cohort["survival_months"].to_numpy(float)
        )
        followup_times, followup_survival = kaplan_meier_estimator(
            y["event"], y["time"], reverse=True
        )
        reached = np.flatnonzero(followup_survival <= 0.5)
        audit.setdefault("outcome_summaries", {})[endpoint] = {
            "n": len(y),
            "events": int(y["event"].sum()),
            "reverse_km_median_followup_months": (
                float(followup_times[reached[0]]) if len(reached) else None
            ),
        }
        shift[endpoint] = covariate_shift_report(
            shift_reporting_frame(train, run.config.preprocessing.unknown_category),
            shift_reporting_frame(cohort, run.config.preprocessing.unknown_category),
            numeric_columns=run.config.preprocessing.numeric_columns,
            categorical_columns=run.config.preprocessing.categorical_columns,
            minimum_group_size=cfg["minimum_group_size"],
            source_quantiles=cfg["source_quantiles"],
        )
        bootstrap_cache = {}

        def summarize_interval(
            outcomes, intervals, group_key, *, endpoint=endpoint, bootstrap_cache=bootstrap_cache
        ):
            cache_key = (group_key, intervals.horizon)
            kwargs = {**evaluation_args, "seed": _seed(run, "external_bootstrap", endpoint)}
            if cache_key not in bootstrap_cache:
                bootstrap_cache[cache_key] = prepare_external_coverage_bootstrap(
                    outcomes,
                    horizon=intervals.horizon,
                    **{
                        k: v
                        for k, v in kwargs.items()
                        if k not in {"confidence_level", "minimum_success_fraction"}
                    },
                )
            return external_coverage(
                outcomes, intervals, prepared_bootstrap=bootstrap_cache[cache_key], **kwargs
            )

        predictions = {}
        for key, record in state["models"].items():
            if record["endpoint"] != endpoint:
                continue
            pre = TrainingPreprocessor.load(Path(state["preprocessors"][record["feature_set"]]))
            X = pre.transform(cohort)
            model = load_fit(record)
            predictions[key.removeprefix(endpoint + "__")] = {
                "risk": model.predict_risk(X),
                "survival": model.predict_survival_function(X, np.array(cfg["time_grid_months"])),
            }
            ridge = None
            if key in state["ridge"]:
                item = state["ridge"][key]
                ridge = (
                    CoxPHModel.load(item["path"]),
                    QinBootstrap(np.array(item["pivots"]), item["diagnostics"]),
                )
                predictions[f"cox_ridge__{record['feature_set']}"] = {
                    "risk": ridge[0].predict_risk(X),
                    "survival": ridge[0].predict_survival_function(
                        X, np.array(cfg["time_grid_months"])
                    ),
                }
            for cell, intervals in _intervals_for_model(
                model,
                X,
                key,
                state["calibration"],
                cfg["alphas"],
                cfg["interval_horizons_months"],
                ridge,
            ):
                groups = {}
                for column in run.config.conformal.coverage_subgroups:
                    groups[column] = {}
                    for level in sorted(cohort[column].dropna().unique()):
                        mask = (cohort[column] == level).to_numpy()
                        if mask.sum() < cfg["minimum_group_size"]:
                            groups[column][str(level)] = {"status": "suppressed_small_group"}
                            continue
                        # Each subgroup estimates its own evaluation censoring distribution.
                        groups[column][str(level)] = summarize_interval(
                            y[mask], intervals.subset(mask), (column, str(level))
                        )
                coverage[cell] = {
                    "endpoint": endpoint,
                    "model": record["model"],
                    "feature_set": record["feature_set"],
                    "method": intervals.method,
                    "alpha": intervals.alpha,
                    "horizon_months": intervals.horizon,
                    "marginal": summarize_interval(y, intervals, "marginal"),
                    "subgroups": groups,
                }
            print(f"TCGA predictions and coverage: {key}", flush=True)
        performance[endpoint] = external_metrics(
            y,
            predictions,
            np.array(cfg["time_grid_months"]),
            seed=_seed(run, "external_bootstrap", endpoint),
            **evaluation_args,
        )
        if cfg["complete_predictor_sensitivity"]:
            features = cfg["clinical_features"] + cfg["molecular_features"]
            missing = shift_reporting_frame(
                cohort[features], run.config.preprocessing.unknown_category
            )
            complete = missing.notna().all(axis=1).to_numpy()
            performance[endpoint]["complete_predictor_sensitivity"] = external_metrics(
                y[complete],
                {
                    name: {k: v[complete] for k, v in values.items()}
                    for name, values in predictions.items()
                },
                np.array(cfg["time_grid_months"]),
                seed=_seed(run, "external_complete_bootstrap", endpoint),
                **evaluation_args,
            )
            audit["outcome_summaries"][endpoint]["n_complete_common_predictors"] = int(
                complete.sum()
            )
        print(f"TCGA performance evaluated: {endpoint}", flush=True)
    artifacts = []
    for name, report in [
        ("cohort_audit", audit),
        ("covariate_shift", shift),
        ("performance", performance),
        ("coverage", coverage),
    ]:
        path = directory / f"{name}.json"
        write_json(path, report)
        artifacts.append(path)
    _verify_hashes(plan["frozen_inputs_sha256"])
    _verify_hashes({str(PROJECT_ROOT / p): h for p, h in plan["source_sha256"].items()})
    return artifacts
