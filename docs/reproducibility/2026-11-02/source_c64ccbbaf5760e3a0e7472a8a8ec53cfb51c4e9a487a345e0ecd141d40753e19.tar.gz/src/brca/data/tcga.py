"""Public TCGA clinical source harmonization for a separately declared transport study.

TCGA PanCanAtlas supplies curated outcomes and PAM50; TCGA Firehose Legacy
supplies baseline receptor measurements. No fitting occurs here. Histologic
specimen dimensions and T/N stages are never substituted for tumour size or
positive-node count. TCGA DSS is a death-with-tumour proxy, not adjudicated
breast-cancer-specific death. Its outcome frame is explicitly separate from OS.
"""

from __future__ import annotations

import gzip
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

from brca.data.cbioportal import RAW_FILES, to_wide
from brca.data.schema import validate

PANCAN_STUDY_ID = "brca_tcga_pan_can_atlas_2018"
LEGACY_STUDY_ID = "brca_tcga"
COMMON_CLINICAL = ("age_at_diagnosis", "er_status", "pr_status", "her2_status")
STRUCTURALLY_MISSING = ("tumor_size", "tumor_grade", "lymph_nodes_positive")
ENDPOINT_FIELDS = {
    "overall": ("OS_MONTHS", "OS_STATUS", {"0:LIVING": False, "1:DECEASED": True}),
    "disease_specific": (
        "DSS_MONTHS",
        "DSS_STATUS",
        {"0:ALIVE OR DEAD TUMOR FREE": False, "1:DEAD WITH TUMOR": True},
    ),
}
PAM50_MAPPING = {f"BRCA_{level}": level for level in ("LumA", "LumB", "Her2", "Basal", "Normal")}
MISSING_VALUES = frozenset(
    {"", "NA", "N/A", "NAN", "[NOT AVAILABLE]", "[NOT APPLICABLE]", "[NOT EVALUATED]", "[UNKNOWN]"}
)
RECEPTOR_VALUES = frozenset({"Positive", "Negative", "Equivocal", "Indeterminate", "Unknown"})
PANCAN_REQUIRED = frozenset(
    {"AGE", "SEX", "SUBTYPE", "OS_MONTHS", "OS_STATUS", "DSS_MONTHS", "DSS_STATUS"}
)
LEGACY_REQUIRED = frozenset(
    {"ER_STATUS_BY_IHC", "PR_STATUS_BY_IHC", "IHC_HER2", "HER2_FISH_STATUS"}
)


def load_tcga_snapshot(path: Path | str, expected_study_id: str) -> dict:
    """Load a public snapshot only after verifying every payload and its study ID."""
    root = Path(path)
    provenance = json.loads((root / "PROVENANCE.json").read_text())
    if (
        provenance.get("study_id") != expected_study_id
        or provenance.get("public_study") is not True
    ):
        raise ValueError("TCGA snapshot study identity or public-access provenance is invalid.")
    checksums = provenance.get("files_sha256", {})
    if set(checksums) != set(RAW_FILES.values()):
        raise ValueError("TCGA provenance must contain exactly the four source payload checksums.")
    payloads = {}
    for key, filename in RAW_FILES.items():
        path = root / filename
        if hashlib.sha256(path.read_bytes()).hexdigest() != checksums[filename]:
            raise ValueError("TCGA snapshot checksum mismatch; restore the original source.")
        with gzip.open(path, "rt") as handle:
            payloads[key] = json.load(handle)
    _check_identity(payloads, expected_study_id)
    return payloads


def _check_identity(payloads: dict, expected_study_id: str) -> None:
    study = payloads.get("study", {})
    if study.get("studyId") != expected_study_id or study.get("publicStudy") is not True:
        raise ValueError("TCGA source has the wrong study identifier or is not marked public.")
    for kind in ("patient", "sample"):
        records = payloads.get(kind)
        if not isinstance(records, list) or not records:
            raise ValueError(f"TCGA source {kind} table is empty or malformed.")
        if any(record.get("studyId", expected_study_id) != expected_study_id for record in records):
            raise ValueError("TCGA source contains clinical records from another study.")


def _clean(series: pd.Series) -> pd.Series:
    strings = series.astype("string").str.strip()
    return strings.mask(strings.str.upper().isin(MISSING_VALUES))


def _numeric(series: pd.Series, field: str) -> pd.Series:
    source = _clean(series)
    values = pd.to_numeric(source, errors="coerce").astype(float)
    if (source.notna() & values.isna()).any() or np.isinf(values).any():
        raise ValueError(f"Invalid non-numeric or infinite TCGA source value in {field}.")
    return values


def _categories(series: pd.Series, allowed: set | frozenset, field: str) -> pd.Series:
    source = _clean(series)
    if not source.dropna().isin(allowed).all():
        raise ValueError(f"Unexpected TCGA category in {field}; the source mapping needs review.")
    return source


def _patients(payloads: dict, required: frozenset) -> pd.DataFrame:
    records = payloads["patient"]
    if any(
        not isinstance(record.get("patientId"), str) or not record["patientId"].strip()
        for record in records
    ):
        raise ValueError("TCGA patient identifiers must be nonempty strings.")
    patients = to_wide(records, "patientId")
    if not required <= set(patients.columns):
        raise ValueError("TCGA patient source lacks attributes required by the fixed protocol.")
    return patients


def validate_tcga_payloads(pancan: dict, legacy: dict) -> None:
    """Check acquisition schema without analyzing outcomes or predictors."""
    _check_identity(pancan, PANCAN_STUDY_ID)
    _check_identity(legacy, LEGACY_STUDY_ID)
    _patients(pancan, PANCAN_REQUIRED)
    _patients(legacy, LEGACY_REQUIRED)
    _primary_patient_ids(pancan)


def _primary_patient_ids(payloads: dict) -> set[str]:
    records = payloads["sample"]
    if any(
        not isinstance(row.get(key), str) or not row[key].strip()
        for row in records
        for key in ("patientId", "sampleId")
    ):
        raise ValueError("TCGA sample records must identify both patient and sample.")
    links = pd.DataFrame(records)[["patientId", "sampleId"]].drop_duplicates()
    if links["sampleId"].duplicated().any():
        raise ValueError("A TCGA sample is linked to multiple patients.")
    samples = to_wide(records, "sampleId")
    if "SAMPLE_TYPE" not in samples.columns:
        raise ValueError("TCGA samples lack the primary-tumour eligibility field.")
    sample_types = _categories(
        samples["SAMPLE_TYPE"], {"Primary", "Metastasis", "Recurrence", "Normal"}, "SAMPLE_TYPE"
    )
    primary = links[links["sampleId"].isin(samples.index[sample_types.eq("Primary")])]
    if primary["patientId"].duplicated().any():
        raise ValueError(
            "Multiple primary TCGA samples per patient need an explicit selection rule."
        )
    return set(primary["patientId"])


def prepare_tcga(
    pancan: dict,
    legacy: dict,
    *,
    female_only: bool = True,
    her2_rule: str = "ihc_then_fish",
) -> tuple[dict[str, pd.DataFrame], dict]:
    """Return separate OS/DSS cohorts plus an aggregate compatibility audit.

    ``pancan`` and ``legacy`` are verified raw payload dictionaries from
    :func:`load_tcga_snapshot`. Missing predictor values are retained; every
    imputer and encoder must subsequently be fitted on METABRIC training only.
    Each endpoint uses its own observed time and exclusion mask. No exclusion
    depends on whether an observed outcome is an event or a censoring time.
    """
    validate_tcga_payloads(pancan, legacy)
    if type(female_only) is not bool:
        raise ValueError("female_only must be explicitly boolean.")
    if her2_rule != "ihc_then_fish":
        raise ValueError("Only the declared ihc_then_fish HER2 mapping is implemented.")
    source = _patients(pancan, PANCAN_REQUIRED)
    legacy_source = _patients(legacy, LEGACY_REQUIRED).reindex(source.index)
    sex = _categories(source["SEX"], {"Female", "Male"}, "SEX")
    eligible = pd.Series(True, index=source.index)
    exclusions = {}
    for reason, invalid in (
        ("without_unique_primary_sample", ~source.index.isin(_primary_patient_ids(pancan))),
        (
            "not_recorded_female",
            ~sex.eq("Female").fillna(False)
            if female_only
            else pd.Series(False, index=source.index),
        ),
    ):
        exclusions[reason] = int((eligible & invalid).sum())
        eligible &= ~invalid
    age = _numeric(source["AGE"], "AGE")
    if age.dropna().le(0).any():
        raise ValueError("TCGA age must be positive when recorded.")
    features = pd.DataFrame(index=source.index)
    features["patient_id"] = source.index.astype(str)
    features["age_at_diagnosis"] = age
    for name in STRUCTURALLY_MISSING:
        features[name] = np.nan
    for name, field in (("er_status", "ER_STATUS_BY_IHC"), ("pr_status", "PR_STATUS_BY_IHC")):
        categorical = _categories(legacy_source[field], RECEPTOR_VALUES, field)
        features[name] = categorical.map({"Positive": "positive", "Negative": "negative"}).fillna(
            "unknown"
        )
    ihc = _categories(legacy_source["IHC_HER2"], RECEPTOR_VALUES, "IHC_HER2")
    fish = _categories(legacy_source["HER2_FISH_STATUS"], RECEPTOR_VALUES, "HER2_FISH_STATUS")
    definite = {"Positive": "positive", "Negative": "negative"}
    ihc_binary, fish_binary = ihc.map(definite), fish.map(definite)
    features["her2_status"] = ihc_binary.fillna(fish_binary).fillna("unknown")
    subtype = _categories(source["SUBTYPE"], set(PAM50_MAPPING), "SUBTYPE")
    features["pam50_subtype"] = subtype.map(PAM50_MAPPING).fillna("unknown")
    os_status = _categories(source["OS_STATUS"], set(ENDPOINT_FIELDS["overall"][2]), "OS_STATUS")
    dss_status = _categories(
        source["DSS_STATUS"], set(ENDPOINT_FIELDS["disease_specific"][2]), "DSS_STATUS"
    )
    if (dss_status.eq("1:DEAD WITH TUMOR") & os_status.eq("0:LIVING")).any():
        raise ValueError("TCGA DSS event contradicts recorded living OS status.")
    frames, endpoint_audits = {}, {}
    for endpoint, (time_field, status_field, mapping) in ENDPOINT_FIELDS.items():
        time = _numeric(source[time_field], time_field)
        status = _categories(source[status_field], set(mapping), status_field)
        keep = eligible.copy()
        endpoint_exclusions = {}
        for reason, invalid in (
            ("missing_endpoint_time_or_status", time.isna() | status.isna()),
            ("nonpositive_endpoint_time", time.le(0)),
        ):
            endpoint_exclusions[reason] = int((keep & invalid).sum())
            keep &= ~invalid
        frame = features.loc[keep].copy()
        frame["survival_months"] = time.loc[keep].astype(float)
        frame["event"] = status.loc[keep].map(mapping).astype(bool)
        frame = frame.sort_index().reset_index(drop=True)
        validate(frame)
        frames[endpoint] = frame
        endpoint_audits[endpoint] = {
            "analysis_patients": len(frame),
            "exclusions_sequential": endpoint_exclusions,
            "source_time_field": time_field,
            "source_status_field": status_field,
            "missing_predictors": {
                name: int((frame[name].isna() | frame[name].eq("unknown")).sum())
                for name in (*COMMON_CLINICAL, "pam50_subtype", *STRUCTURALLY_MISSING)
            },
        }
    audit = {
        "input_kind": "real_tcga_public_clinical",
        "pancan_study": PANCAN_STUDY_ID,
        "legacy_study": LEGACY_STUDY_ID,
        "raw_patients": len(source),
        "common_eligibility_exclusions_sequential": exclusions,
        "eligible_patients_before_endpoint_exclusions": int(eligible.sum()),
        "female_only": female_only,
        "patients_without_legacy_predictor_record": int(
            (~source.index.isin(_patients(legacy, LEGACY_REQUIRED).index) & eligible).sum()
        ),
        "common_clinical_features": list(COMMON_CLINICAL),
        "molecular_addition": "pam50_subtype",
        "structurally_unavailable_for_original_model": list(STRUCTURALLY_MISSING),
        "positive_nodes_note": (
            "H&E/IHC-specific legacy counts are available but excluded from the declared "
            "common-feature model; no numeric node proxy is assigned."
        ),
        "tumour_size_note": (
            "Specimen dimensions and AJCC T-stage are not tumour size; "
            "neither is converted to millimetres."
        ),
        "her2_rule": her2_rule,
        "her2_fish_fallback_patients": int(
            (eligible & ihc_binary.isna() & fish_binary.notna()).sum()
        ),
        "her2_definite_ihc_fish_disagreements": int(
            (eligible & ihc_binary.notna() & fish_binary.notna() & ihc_binary.ne(fish_binary)).sum()
        ),
        "subtype_note": (
            "Five PAM50 labels mapped; claudin-low is unavailable as a separate "
            "TCGA label, and missing subtypes remain unknown."
        ),
        "endpoint_compatibility": {
            "overall": (
                "Time from diagnosis to death from any cause or last contact; "
                "principal external outcome."
            ),
            "disease_specific": (
                "Exploratory death-with-tumour proxy; not equivalent to METABRIC "
                "recorded cause-specific death."
            ),
        },
        "endpoints": endpoint_audits,
        "fit_transforms": False,
        "outcome_units": "months",
        "administrative_censoring_months": None,
    }
    return frames, audit
