"""data layer -- see .claude/rules/ for the invariants that apply here."""
