"""External-cohort evaluation with target-population censoring nuisance estimates.

Predictive fits, preprocessing and conformal calibration remain fixed. Only the
evaluation censoring distribution is estimated using the external outcomes and
reestimated in each ordinary paired patient bootstrap. Marginal IPCW assumes
independent censoring in the target cohort; transport does not preserve a source
conformal coverage guarantee. Unsupported prespecified horizons remain visible.
"""

from __future__ import annotations

import warnings
from collections.abc import Mapping
from contextlib import suppress
from dataclasses import dataclass
from hashlib import sha256
from typing import Any

import numpy as np
from sksurv.exceptions import NoComparablePairException
from sksurv.metrics import brier_score, concordance_index_ipcw, cumulative_dynamic_auc

from brca.conformal.survival import (
    CensoringDistribution,
    PredictionIntervals,
    _bootstrap_interval_draws,
    _coverage_indicators,
    _draw_summary,
    _finite_number,
    _ipcw_weights,
    _labels,
    _validate_bootstrap,
)
from brca.evaluation.metrics import _capped_test_labels

_CURVES = ("brier", "auc", "uno_c")
_EXPECTED_ERRORS = (ValueError, NoComparablePairException, ZeroDivisionError, RuntimeWarning)


def _validate(
    y: np.ndarray,
    bootstrap_replicates: int,
    confidence_level: float,
    minimum_success_fraction: float,
    min_censoring_survival: float,
    minimum_events: int,
    minimum_at_risk: int,
) -> None:
    _labels(y)  # Unlike a model fit, external evaluation permits no observed events.
    _validate_bootstrap(
        bootstrap_replicates, confidence_level, minimum_success_fraction, None, len(y)
    )
    if not 0 < min_censoring_survival <= 1:
        raise ValueError("min_censoring_survival must be in (0, 1].")
    if any(
        not isinstance(value, int) or isinstance(value, bool) or value < 1
        for value in (minimum_events, minimum_at_risk)
    ):
        raise ValueError("Event and at-risk support thresholds must be positive integers.")


def _support(
    y: np.ndarray,
    horizon: float,
    min_censoring_survival: float,
    minimum_events: int,
    minimum_at_risk: int,
    *,
    restricted_target: bool = False,
) -> dict[str, Any]:
    """Diagnose a fixed horizon; never choose a replacement based on outcomes."""
    event, time = _labels(y)
    events = int((event & (time <= horizon)).sum())
    at_risk = int(((time >= horizon) if restricted_target else (time > horizon)).sum())
    reasons = []
    if events < minimum_events:
        reasons.append("insufficient_observed_events_by_horizon")
    if at_risk < minimum_at_risk:
        reasons.append("insufficient_followup_at_horizon")
    g = np.nan
    if len(y) and np.isfinite(horizon):
        # Metrics use sksurv's G(t), while restricted coverage weights use
        # P(C >= t)=G(t-), preserving the original interval tie convention.
        evaluation_time = horizon if restricted_target else np.nextafter(horizon, np.inf)
        g = CensoringDistribution.fit(y).survival_ge(np.array([evaluation_time]))[0]
    if not np.isfinite(g) or g < min_censoring_survival:
        reasons.append("insufficient_censoring_support")
    return {
        "time_months": _finite_number(horizon),
        "n_events_by_horizon": events,
        "n_at_risk": at_risk,
        "at_risk_definition": "Y >= horizon" if restricted_target else "Y > horizon",
        "censoring_survival": _finite_number(g),
        "censoring_survival_convention": "G(t-)" if restricted_target else "G(t)",
        "supported": not reasons,
        "reasons": reasons,
    }


def _values(
    y: np.ndarray,
    predictions: Mapping[str, Mapping[str, np.ndarray]],
    times: np.ndarray,
    support: list[dict[str, Any]],
) -> dict[str, dict[str, np.ndarray]]:
    results = {}
    for name, arrays in predictions.items():
        values = {metric: np.full(len(times), np.nan) for metric in _CURVES}
        values["ibs"] = np.array(np.nan)
        for j, horizon in enumerate(times):
            if not support[j]["supported"]:
                continue
            # Cap separately for each horizon: later unsupported events must not
            # prevent early AUC evaluation. The reference y remains UNCAPPED.
            capped, _ = _capped_test_labels(y, horizon)
            with warnings.catch_warnings():
                warnings.simplefilter("error", RuntimeWarning)
                with suppress(*_EXPECTED_ERRORS):
                    values["brier"][j] = brier_score(
                        y, capped, arrays["survival"][:, j], [horizon]
                    )[1][0]
                with suppress(*_EXPECTED_ERRORS):
                    values["auc"][j] = cumulative_dynamic_auc(
                        y, capped, 1 - arrays["survival"][:, j], [horizon]
                    )[0][0]
                with suppress(*_EXPECTED_ERRORS):
                    values["uno_c"][j] = concordance_index_ipcw(
                        y, capped, arrays["risk"], tau=np.nextafter(horizon, np.inf)
                    )[0]
        if np.isfinite(values["brier"]).all():
            # Same trapezoidal definition as sksurv integrated_brier_score;
            # the exact prespecified grid is retained, including its first time.
            values["ibs"] = np.array(np.trapezoid(values["brier"], times) / (times[-1] - times[0]))
        results[name] = values
    return results


def _summary(
    point: float,
    draws: np.ndarray,
    confidence_level: float,
    minimum_success_fraction: float,
    reasons: list[str],
) -> dict[str, Any]:
    result = _draw_summary(draws, confidence_level, minimum_success_fraction)
    result["estimate"] = _finite_number(point)
    result["estimate_is_infinite"] = bool(np.isinf(point))
    if np.isnan(point):
        result.update(
            status="unavailable",
            ci=None,
            ci_is_infinite=None,
            reasons=reasons or ["metric_undefined_on_original_sample"],
        )
    else:
        result["reasons"] = []
    return result


def _model_summary(
    point: dict[str, np.ndarray],
    draws: dict[str, np.ndarray],
    times: np.ndarray,
    support: list[dict[str, Any]],
    confidence_level: float,
    minimum_success_fraction: float,
) -> dict[str, Any]:
    result = {
        metric: [
            {
                "time_months": float(time),
                **_summary(
                    float(point[metric][j]),
                    draws[metric][:, j],
                    confidence_level,
                    minimum_success_fraction,
                    support[j]["reasons"],
                ),
            }
            for j, time in enumerate(times)
        ]
        for metric in _CURVES
    }
    result["ibs"] = {
        "integration_range_months": [float(times[0]), float(times[-1])],
        "integration_grid_months": times.tolist(),
        **_summary(
            float(point["ibs"]),
            draws["ibs"],
            confidence_level,
            minimum_success_fraction,
            ["complete_prespecified_grid_not_supported"]
            if not all(item["supported"] for item in support)
            else [],
        ),
    }
    return result


def external_metrics(
    y: np.ndarray,
    predictions: Mapping[str, Mapping[str, np.ndarray]],
    times: np.ndarray,
    *,
    bootstrap_replicates: int,
    seed: int,
    confidence_level: float,
    min_censoring_survival: float,
    minimum_success_fraction: float,
    minimum_events: int,
    minimum_at_risk: int,
) -> dict[str, Any]:
    """Evaluate frozen predictions at every prespecified external horizon.

    ``times`` must be fixed in the caller's protocol before outcome evaluation
    (the external study uses 12, 36 and 60 months). No adaptive grid is selected.
    All horizons receive explicit support diagnostics and truncated Uno C,
    time-dependent AUC and Brier estimates. IBS requires the entire fixed grid.
    Passing target y as sksurv's reference estimates an EVALUATION nuisance in
    the target population; it does not train or calibrate a predictive model.
    """
    _validate(
        y,
        bootstrap_replicates,
        confidence_level,
        minimum_success_fraction,
        min_censoring_survival,
        minimum_events,
        minimum_at_risk,
    )
    times = np.asarray(times, dtype=float)
    if (
        times.ndim != 1
        or len(times) < 2
        or not np.isfinite(times).all()
        or np.any(times <= 0)
        or np.any(np.diff(times) <= 0)
    ):
        raise ValueError("Prespecified times must be positive, finite and strictly increasing.")
    if not predictions or not all(isinstance(name, str) for name in predictions):
        raise ValueError("At least one model with a string identifier is required.")
    validated = {}
    for name in sorted(predictions):
        risk = np.asarray(predictions[name]["risk"], float)
        survival = np.asarray(predictions[name]["survival"], float)
        if risk.shape != (len(y),) or survival.shape != (len(y), len(times)):
            raise ValueError("Prediction arrays must align with target patients and fixed times.")
        if not np.isfinite(risk).all() or not np.isfinite(survival).all():
            raise ValueError("Predictions must be finite.")
        if np.any((survival < 0) | (survival > 1)) or np.any(np.diff(survival, axis=1) > 0):
            raise ValueError("Survival probabilities must be in [0,1] and non-increasing.")
        validated[name] = {"risk": risk, "survival": survival}
    settings = (min_censoring_survival, minimum_events, minimum_at_risk)
    support = [_support(y, horizon, *settings) for horizon in times]
    point = _values(y, validated, times, support)
    draws = {
        name: {
            **{metric: np.full((bootstrap_replicates, len(times)), np.nan) for metric in _CURVES},
            "ibs": np.full(bootstrap_replicates, np.nan),
        }
        for name in validated
    }
    rng = np.random.default_rng(seed)
    for b in range(bootstrap_replicates if len(y) else 0):
        indices = rng.integers(0, len(y), size=len(y))
        boot_y = y[indices]
        boot_support = [_support(boot_y, horizon, *settings) for horizon in times]
        boot_predictions = {
            name: {key: values[indices] for key, values in arrays.items()}
            for name, arrays in validated.items()
        }
        values = _values(boot_y, boot_predictions, times, boot_support)
        for name in validated:
            for metric in draws[name]:
                draws[name][metric][b] = values[name][metric]
    summary_args = (times, support, confidence_level, minimum_success_fraction)
    models = {name: _model_summary(point[name], draws[name], *summary_args) for name in validated}
    comparisons = {}
    for clinical in validated:
        if not clinical.endswith("__clinical"):
            continue
        base = clinical.removesuffix("__clinical")
        molecular = f"{base}__clinical_molecular"
        if molecular not in validated:
            continue
        differences = {key: point[molecular][key] - point[clinical][key] for key in point[clinical]}
        paired = {key: draws[molecular][key] - draws[clinical][key] for key in point[clinical]}
        comparisons[base] = {
            "difference": "clinical_molecular_minus_clinical",
            "positive_favors_molecular": {"uno_c": True, "auc": True, "brier": False, "ibs": False},
            **_model_summary(differences, paired, *summary_args),
        }
    return {
        "schema_version": 1,
        "n_target": len(y),
        "n_target_events": int(y["event"].sum()),
        "time_grid_months": times.tolist(),
        "time_grid_changed_using_target_outcomes": False,
        "support": support,
        "support_thresholds": {
            "min_censoring_survival": min_censoring_survival,
            "minimum_events": minimum_events,
            "minimum_at_risk": minimum_at_risk,
        },
        "censoring_estimator": "target_reverse_kaplan_meier_uncapped_followup",
        "censoring_assumption": "C independent of (T,X) in the target population",
        "censoring_fit_role": "evaluation_nuisance_only",
        "auc_risk_definition": "1_minus_survival_at_each_grid_time",
        "uno_c_horizon_rule": "each_prespecified_horizon_including_events_at_horizon",
        "bootstrap": {
            "method": "paired_ordinary_target_patient_percentile",
            "replicates": bootstrap_replicates,
            "seed": seed,
            "confidence_level": confidence_level,
            "minimum_success_fraction": minimum_success_fraction,
            "target_censoring_reestimated": True,
            "models_refitted": False,
            "calibration_refitted": False,
            "multiple_comparisons_adjusted": False,
        },
        "models": models,
        "paired_feature_comparisons": comparisons,
    }


def _coverage_values(
    y: np.ndarray,
    intervals: PredictionIntervals,
    min_censoring_survival: float,
    minimum_events: int,
    minimum_at_risk: int,
) -> tuple[dict[str, float], dict[str, Any]]:
    support = _support(
        y,
        intervals.horizon,
        min_censoring_survival,
        minimum_events,
        minimum_at_risk,
        restricted_target=True,
    )
    certain, possible, covered = _coverage_indicators(y, intervals)
    widths = (
        np.quantile(intervals.width, [0.25, 0.5, 0.75], method="inverted_cdf")
        if len(y)
        else [np.nan] * 3
    )
    values = {
        "observable_coverage_lower": float(certain.mean()) if len(y) else np.nan,
        "observable_coverage_upper": float(possible.mean()) if len(y) else np.nan,
        "width_q25_months": float(widths[0]),
        "width_median_months": float(widths[1]),
        "width_q75_months": float(widths[2]),
        "full_support_fraction": float(
            ((intervals.lower == 0) & (intervals.upper == intervals.horizon)).mean()
        )
        if len(y)
        else np.nan,
        "ipcw_coverage": np.nan,
        "ipcw_ht_coverage": np.nan,
    }
    if support["supported"]:
        weights, diagnostics = _ipcw_weights(
            y, CensoringDistribution.fit(y), intervals.horizon, min_censoring_survival
        )
        support["weight_diagnostics"] = diagnostics
        if weights is not None and weights.sum() > 0:
            values["ipcw_coverage"] = float(np.dot(weights, covered) / weights.sum())
            values["ipcw_ht_coverage"] = float(np.dot(weights, covered) / len(y))
    return values, support


@dataclass(frozen=True)
class ExternalCoverageBootstrap:
    """Reusable nuisance fits for one ordered cohort, horizon and bootstrap design.

    Each row of weights was fitted on that row's resampled target cohort. Arrays
    are read-only; an outcome digest prevents accidental reuse for another
    subgroup or order. Memory scales as two replicates-by-patients matrices.
    """

    outcome_digest: str
    horizon: float
    bootstrap_replicates: int
    seed: int
    min_censoring_survival: float
    minimum_events: int
    minimum_at_risk: int
    selections: np.ndarray
    weights: np.ndarray


def _outcome_digest(y: np.ndarray) -> str:
    return sha256(y["event"].tobytes() + y["time"].astype("<f8").tobytes()).hexdigest()


def prepare_external_coverage_bootstrap(
    y: np.ndarray,
    *,
    horizon: float,
    bootstrap_replicates: int,
    seed: int,
    min_censoring_survival: float,
    minimum_events: int,
    minimum_at_risk: int,
) -> ExternalCoverageBootstrap:
    """Fit target censoring once per draw, reusable across all interval methods."""
    _validate(
        y,
        bootstrap_replicates,
        0.95,
        0.9,
        min_censoring_survival,
        minimum_events,
        minimum_at_risk,
    )
    if np.isnan(horizon) or horizon <= 0:
        raise ValueError("horizon must be positive.")
    settings = (min_censoring_survival, minimum_events, minimum_at_risk)
    selections = np.empty((bootstrap_replicates, len(y)), dtype=np.int64)
    weights = np.full((bootstrap_replicates, len(y)), np.nan)
    rng = np.random.default_rng(seed)
    for b in range(bootstrap_replicates if len(y) else 0):
        selections[b] = rng.integers(0, len(y), size=len(y))
        boot_y = y[selections[b]]
        support = _support(boot_y, horizon, *settings, restricted_target=True)
        if support["supported"]:
            draw_weights, _ = _ipcw_weights(
                boot_y, CensoringDistribution.fit(boot_y), horizon, min_censoring_survival
            )
            if draw_weights is not None and draw_weights.sum() > 0:
                weights[b] = draw_weights
    selections.setflags(write=False)
    weights.setflags(write=False)
    return ExternalCoverageBootstrap(
        _outcome_digest(y),
        horizon,
        bootstrap_replicates,
        seed,
        min_censoring_survival,
        minimum_events,
        minimum_at_risk,
        selections,
        weights,
    )


def external_coverage(
    y: np.ndarray,
    intervals: PredictionIntervals,
    *,
    bootstrap_replicates: int,
    seed: int,
    confidence_level: float,
    min_censoring_survival: float,
    minimum_success_fraction: float,
    minimum_events: int,
    minimum_at_risk: int,
    prepared_bootstrap: ExternalCoverageBootstrap | None = None,
) -> dict[str, Any]:
    """Evaluate transported intervals, without any target conformal recalibration.

    Observable bounds on realised coverage require no independent-censoring
    assumption. IPCW is a separate target-KM approximation with explicit support
    gates. CIs include target censoring-estimation uncertainty via refitting in
    every bootstrap; source model and source calibration uncertainty are omitted.
    """
    _validate(
        y,
        bootstrap_replicates,
        confidence_level,
        minimum_success_fraction,
        min_censoring_survival,
        minimum_events,
        minimum_at_risk,
    )
    if len(y) != len(intervals.lower):
        raise ValueError("Target labels and transported intervals must align.")
    settings = (min_censoring_survival, minimum_events, minimum_at_risk)
    point, support = _coverage_values(y, intervals, *settings)
    draws = {key: np.full(bootstrap_replicates, np.nan) for key in point}
    if prepared_bootstrap is None:
        prepared_bootstrap = prepare_external_coverage_bootstrap(
            y,
            horizon=intervals.horizon,
            bootstrap_replicates=bootstrap_replicates,
            seed=seed,
            min_censoring_survival=min_censoring_survival,
            minimum_events=minimum_events,
            minimum_at_risk=minimum_at_risk,
        )
    expected = (_outcome_digest(y), intervals.horizon, bootstrap_replicates, seed, *settings)
    actual = (
        prepared_bootstrap.outcome_digest,
        prepared_bootstrap.horizon,
        prepared_bootstrap.bootstrap_replicates,
        prepared_bootstrap.seed,
        prepared_bootstrap.min_censoring_survival,
        prepared_bootstrap.minimum_events,
        prepared_bootstrap.minimum_at_risk,
    )
    if actual != expected:
        raise ValueError("Prepared bootstrap must match ordered outcomes, horizon and settings.")
    if bootstrap_replicates and len(y):
        selections, weights = prepared_bootstrap.selections, prepared_bootstrap.weights
        bounded_draws = _bootstrap_interval_draws(y, intervals, selections, weights=None)
        draws.update({key: bounded_draws[key] for key in draws if not key.startswith("ipcw")})
        covered = _coverage_indicators(y, intervals)[2]
        numerator = (weights * covered[selections]).sum(axis=1)
        denominator = weights.sum(axis=1)
        np.divide(numerator, denominator, out=draws["ipcw_coverage"], where=denominator > 0)
        draws["ipcw_ht_coverage"] = numerator / len(y)
    summaries = {
        key: _summary(
            value,
            draws[key],
            confidence_level,
            minimum_success_fraction,
            support["reasons"] if key.startswith("ipcw") else [],
        )
        for key, value in point.items()
    }
    return {
        "schema_version": 1,
        "n_target": len(y),
        "n_test": len(y),
        "n_target_events": int(y["event"].sum()),
        "n_known_target": int((y["event"] | (y["time"] >= intervals.horizon)).sum()),
        "n_censored_before_horizon": int((~y["event"] & (y["time"] < intervals.horizon)).sum()),
        "method": intervals.method,
        "alpha": intervals.alpha,
        "nominal_coverage": 1 - intervals.alpha,
        "n_cal": intervals.n_cal,
        "horizon_months": _finite_number(intervals.horizon),
        "target": "min(T,horizon)" if np.isfinite(intervals.horizon) else "T",
        **{key: _finite_number(value) for key, value in point.items()},
        "width_median_is_infinite": bool(np.isinf(point["width_median_months"])),
        "ipcw_status": "available" if np.isfinite(point["ipcw_coverage"]) else "unavailable",
        "ipcw_support": support,
        "bootstrap_statistics": summaries,
        "bootstrap_replicates_requested": bootstrap_replicates,
        "bootstrap_seed": seed,
        "confidence_level": confidence_level,
        "minimum_success_fraction": minimum_success_fraction,
        "bootstrap_sampling": "ordinary_target_patient",
        "target_censoring_reestimated_each_bootstrap": True,
        "censoring_fit_role": "evaluation_nuisance_only",
        "censoring_estimator": "target_reverse_kaplan_meier_uncapped_followup",
        "ipcw_assumption": "C independent of (T,X) in target; positive censoring support",
        "ci_scope": "target_patient_bootstrap_conditional_on_source_model_and_calibration",
        "calibration_refitted": False,
        "source_conformal_guarantee_transports": False,
    }
