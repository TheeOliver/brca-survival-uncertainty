"""Independently audit external-validation aggregates and exact artifact digests.

Run on SLURM after stage 05. Never decode raw tables, patient caches, model
pickles or posterior samples. This checks integrity and reported contracts;
it does not reproduce numerical predictions or establish clinical validity.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import tarfile
import tomllib
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path

import yaml

from brca.compute_guard import require_compute_node
from brca.config import PROJECT_ROOT
from brca.manifest import sha256_file

FEATURES = ("clinical", "clinical_molecular")
MODELS = ("cox", "rsf", "weibull")
METHODS = {
    "conservative": "conservative_score_envelope",
    "conservative_lower_bound": "conservative_lower_bound",
    "qin_bootstrap_ridge_cox": "qin_bootstrap_ridge_cox",
}
RESULT_FILES = (
    "plan.json",
    "preparation.json",
    "preparation_binding.json",
    "distribution_shift.json",
    "cohort_audit.json",
    "covariate_shift.json",
    "performance.json",
    "coverage.json",
)


class Checks:
    def __init__(self):
        self.count = 0
        self.failures = []
        self.metric_statuses = Counter()
        self.checked_hashes = {}

    def check(self, condition, label):
        self.count += 1
        if not condition:
            self.failures.append(label)
        return bool(condition)

    def digest(self, path, expected, label):
        path = Path(path)
        actual = sha256_file(path) if path.is_file() else None
        if actual is not None:
            self.checked_hashes[str(path)] = actual
        return self.check(isinstance(expected, str) and actual == expected, label)

    def read(self, path):
        path = Path(path)
        self.check(path.is_file(), f"aggregate exists: {path.name}")
        if not path.is_file():
            return {}
        try:
            data = json.loads(
                path.read_text(), parse_constant=lambda _: (_ for _ in ()).throw(ValueError())
            )
        except (ValueError, OSError):
            self.check(False, f"valid finite JSON: {path.name}")
            return {}
        self.check(isinstance(data, dict), f"aggregate root is an object: {path.name}")
        return data if isinstance(data, dict) else {}

    def finite(self, value, label, lower=None, upper=None, allow_null=False):
        if value is None:
            return self.check(allow_null, label)
        good = (
            isinstance(value, (float, int)) and not isinstance(value, bool) and math.isfinite(value)
        )
        if good and lower is not None:
            good &= value >= lower - 1e-10
        if good and upper is not None:
            good &= value <= upper + 1e-10
        return self.check(good, label)


def summary(checks, row, label, cfg, *, lower=None, upper=None):
    estimate = row.get("estimate")
    status = row.get("status")
    checks.metric_statuses[str(status)] += 1
    checks.finite(
        estimate, f"{label}: estimate domain", lower, upper, allow_null=status == "unavailable"
    )
    valid, failed = row.get("valid_replicates"), row.get("failed_replicates")
    requested = cfg["bootstrap_replicates"]
    counts_ok = (
        isinstance(valid, int)
        and isinstance(failed, int)
        and valid >= 0
        and failed >= 0
        and valid + failed == requested
    )
    checks.check(counts_ok, f"{label}: bootstrap accounting")
    checks.check(
        row.get("minimum_success_fraction") == cfg["minimum_success_fraction"],
        f"{label}: success gate unchanged",
    )
    if counts_ok and requested:
        checks.check(
            math.isclose(row.get("success_fraction", -1), valid / requested),
            f"{label}: success fraction",
        )
    ci = row.get("ci")
    if status in {"unavailable", "bootstrap_gate_failed", "not_requested"}:
        checks.check(ci is None, f"{label}: unavailable CI explicitly null")
        if status == "unavailable":
            checks.check(
                estimate is None and bool(row.get("reasons")), f"{label}: unavailable reason"
            )
        elif status == "bootstrap_gate_failed" and counts_ok:
            checks.check(
                valid < 2 or valid / requested < cfg["minimum_success_fraction"],
                f"{label}: failed gate explained",
            )
    else:
        checks.check(
            status in {"ok", "conditional_on_successful_resamples"},
            f"{label}: recognized success status",
        )
        checks.check(
            counts_ok and valid >= 2 and valid / requested >= cfg["minimum_success_fraction"],
            f"{label}: CI gate passed",
        )
        if checks.check(isinstance(ci, list) and len(ci) == 2, f"{label}: two CI endpoints"):
            lo = checks.finite(ci[0], f"{label}: lower CI domain", lower, upper)
            hi = checks.finite(ci[1], f"{label}: upper CI domain", lower, upper)
            checks.check(lo and hi and ci[0] <= ci[1], f"{label}: ordered CI")
        if counts_ok:
            checks.check((status == "ok") == (failed == 0), f"{label}: resample qualification")
            checks.check(
                row.get("approximate_due_to_failed_resamples") == (failed > 0),
                f"{label}: failed resamples disclosed",
            )


def cell_contracts(endpoints, alphas, horizons):
    cells = {}
    for endpoint in endpoints:
        for feature in FEATURES:
            for model in MODELS:
                methods = list(METHODS) if model == "cox" else list(METHODS)[:2]
                for alpha in alphas:
                    for horizon in horizons:
                        for method in methods:
                            key = (
                                f"{endpoint}__{model}__{feature}__alpha{alpha:g}"
                                f"__horizon{horizon:g}__{method}"
                            )
                            cells[key] = {
                                "endpoint": endpoint,
                                "model": model,
                                "feature_set": feature,
                                "alpha": alpha,
                                "horizon_months": horizon,
                                "method": METHODS[method],
                            }
    return cells


def coverage_row(checks, row, label, cell, cfg, n_cal, n_target=None):
    horizon, alpha = cell["horizon_months"], cell["alpha"]
    checks.check(
        row.get("alpha") == alpha
        and row.get("horizon_months") == horizon
        and row.get("method") == cell["method"],
        f"{label}: interval identity",
    )
    checks.check(
        math.isclose(row.get("nominal_coverage", -1), 1 - alpha), f"{label}: nominal coverage"
    )
    checks.check(row.get("n_cal") == n_cal, f"{label}: calibration/pivot count")
    n = row.get("n_target")
    checks.check(
        isinstance(n, int) and n > 0 and (n_target is None or n == n_target),
        f"{label}: cohort size",
    )
    known, censored = row.get("n_known_target"), row.get("n_censored_before_horizon")
    checks.check(
        isinstance(known, int)
        and isinstance(censored, int)
        and min(known, censored) >= 0
        and known + censored == n,
        f"{label}: known/censored accounting",
    )
    lower, upper = row.get("observable_coverage_lower"), row.get("observable_coverage_upper")
    checks.finite(lower, f"{label}: lower coverage", 0, 1)
    checks.finite(upper, f"{label}: upper coverage", 0, 1)
    checks.check(
        lower is not None and upper is not None and lower <= upper,
        f"{label}: ordered observable bounds",
    )
    widths = [row.get(f"width_{q}_months") for q in ("q25", "median", "q75")]
    good = [checks.finite(w, f"{label}: width {j}", 0, horizon) for j, w in enumerate(widths)]
    checks.check(all(good) and widths == sorted(widths), f"{label}: ordered width quartiles")
    checks.finite(row.get("full_support_fraction"), f"{label}: full support fraction", 0, 1)
    checks.check(
        row.get("source_conformal_guarantee_transports") is False
        and row.get("calibration_refitted") is False,
        f"{label}: transport limitation",
    )
    checks.check(
        row.get("target_censoring_reestimated_each_bootstrap") is True,
        f"{label}: target nuisance resampled",
    )
    support = row.get("ipcw_support", {})
    available = row.get("ipcw_status") == "available"
    checks.check(available == (row.get("ipcw_coverage") is not None), f"{label}: IPCW availability")
    if available:
        checks.check(support.get("supported") is True, f"{label}: IPCW support gate")
        checks.finite(row["ipcw_coverage"], f"{label}: IPCW ratio range", 0, 1)
    for name, statistics in row.get("bootstrap_statistics", {}).items():
        lo, hi = (
            (0, horizon)
            if name.startswith("width_")
            else (0, None)
            if name == "ipcw_ht_coverage"
            else (0, 1)
        )
        summary(checks, statistics, f"{label}/{name}", cfg, lower=lo, upper=hi)
        checks.check(
            statistics.get("estimate") == row.get(name),
            f"{label}/{name}: duplicate point consistency",
        )
    checks.check(
        set(row.get("bootstrap_statistics", {}))
        == {
            "observable_coverage_lower",
            "observable_coverage_upper",
            "width_q25_months",
            "width_median_months",
            "width_q75_months",
            "full_support_fraction",
            "ipcw_coverage",
            "ipcw_ht_coverage",
        },
        f"{label}: complete coverage statistics",
    )


def performance_report(checks, report, label, cfg, n_target):
    checks.check(report.get("n_target") == n_target, f"{label}: cohort size")
    checks.check(
        report.get("time_grid_months") == cfg["time_grid_months"]
        and report.get("time_grid_changed_using_target_outcomes") is False,
        f"{label}: fixed time grid",
    )
    checks.check(
        report.get("censoring_fit_role") == "evaluation_nuisance_only",
        f"{label}: target censoring role",
    )
    bootstrap = report.get("bootstrap", {})
    checks.check(
        bootstrap.get("target_censoring_reestimated") is True
        and bootstrap.get("models_refitted") is False
        and bootstrap.get("calibration_refitted") is False,
        f"{label}: fixed prediction bootstrap",
    )
    expected_models = {
        f"{model}__{feature}" for model in (*MODELS, "cox_ridge") for feature in FEATURES
    }
    checks.check(
        set(report.get("models", {})) == expected_models, f"{label}: eight performance models"
    )
    checks.check(
        set(report.get("paired_feature_comparisons", {})) == {*MODELS, "cox_ridge"},
        f"{label}: four paired feature comparisons",
    )
    for group in ("models", "paired_feature_comparisons"):
        for key, model in report.get(group, {}).items():
            lo, hi = (-1, 1) if group == "paired_feature_comparisons" else (0, 1)
            for metric in ("brier", "auc", "uno_c"):
                rows = model.get(metric, [])
                checks.check(
                    [r.get("time_months") for r in rows] == cfg["time_grid_months"],
                    f"{label}/{key}/{metric}: all fixed horizons",
                )
                for j, row in enumerate(rows):
                    summary(checks, row, f"{label}/{key}/{metric}/{j}", cfg, lower=lo, upper=hi)
                    if j < len(report.get("support", [])) and not report["support"][j]["supported"]:
                        checks.check(
                            row.get("estimate") is None and row.get("status") == "unavailable",
                            f"{label}/{key}/{metric}/{j}: unsupported horizon retained",
                        )
            ibs = model.get("ibs", {})
            checks.check(
                ibs.get("integration_grid_months") == cfg["time_grid_months"],
                f"{label}/{key}: IBS full grid",
            )
            summary(checks, ibs, f"{label}/{key}/ibs", cfg, lower=lo, upper=hi)


def provenance(checks, root, directory, plan, state, settings, default, files):
    checks.digest(
        root / "config/external_validation.yaml",
        plan.get("settings_sha256"),
        "extension config hash",
    )
    checks.digest(root / "config/default.yaml", plan.get("config_sha256"), "original config hash")
    checks.digest(root / "uv.lock", plan.get("lock_sha256"), "dependency lock hash")
    checks.check(plan.get("settings") == settings, "serialized plan settings match config")
    for group in ("source_sha256", "frozen_inputs_sha256", "raw_inputs_sha256"):
        checks.check(bool(plan.get(group)), f"nonempty provenance group {group}")
        for name, digest in plan.get(group, {}).items():
            checks.digest(root / name, digest, f"{group}: {name}")
    for name in ("performance.json", "conformal_coverage.json"):
        path = root / default["paths"]["outputs"] / "metrics" / name
        checks.check(
            str(path) in plan.get("frozen_inputs_sha256", {}),
            f"original {name} bound before extension",
        )
    binding = checks.read(directory / "preparation_binding.json")
    checks.digest(directory / "plan.json", binding.get("plan_sha256"), "preparation plan binding")
    checks.digest(
        directory / "preparation.json",
        binding.get("preparation_sha256"),
        "preparation state binding",
    )
    checks.check(state.get("plan_sha256") == binding.get("plan_sha256"), "state plan identity")
    for path, digest in state.get("artifacts_sha256", {}).items():
        checks.digest(path, digest, f"prepared model/preprocessor artifact: {Path(path).name}")
    for spec in settings["external_validation"]["sources"].values():
        raw = root / settings["paths"]["raw"] / spec["raw_subdir"]
        meta = checks.read(raw / "PROVENANCE.json")
        checks.check(
            meta.get("study_id") == spec["study_id"] and meta.get("public_study") is True,
            f"public TCGA study identity: {spec['study_id']}",
        )
        for name, digest in meta.get("files_sha256", {}).items():
            checks.digest(
                raw / name, digest, f"raw payload integrity only: {spec['study_id']}/{name}"
            )
    manifests = []
    for path in (directory.parent / "manifests").glob("05_external_validation_*.json"):
        data = checks.read(path)
        if data.get("status") == "exploratory_external_and_shift_complete":
            manifests.append((path, data))
    matched = [
        (p, m)
        for p, m in manifests
        if all(
            m.get("artifacts_sha256", {}).get(str(directory / f)) == sha256_file(directory / f)
            for f in files
            if (directory / f).is_file()
        )
    ]
    checks.check(bool(matched), "completed production manifest binds every aggregate")
    if not matched:
        return None
    path, manifest = max(matched, key=lambda pair: pair[0].name)
    checks.check(
        manifest.get("stage") == "05_external_validation" and bool(manifest.get("slurm_job_id")),
        "production ran on SLURM",
    )
    checks.check(
        manifest.get("config_sha256") == plan.get("config_sha256"), "production config binding"
    )
    checks.check(manifest.get("seed") == default["seed"], "production seed binding")
    checks.check(
        bool(manifest.get("git_sha")) and isinstance(manifest.get("git_dirty"), bool),
        "production Git state recorded",
    )
    for name, digest in manifest.get("artifacts_sha256", {}).items():
        checks.digest(name, digest, f"production artifact: {Path(name).name}")
    archive = Path(manifest["source_archive"])
    members = {}
    if checks.digest(archive, manifest.get("source_sha256"), "production source archive hash"):
        with tarfile.open(archive, "r:gz") as handle:
            for member in handle.getmembers():
                name = Path(member.name)
                safe = (
                    member.isfile()
                    and not name.is_absolute()
                    and ".." not in name.parts
                    and name.parts[0] in {"src", "scripts", "config", "pyproject.toml", "uv.lock"}
                    and member.name not in members
                )
                if checks.check(safe, f"source-only archive member: {member.name}"):
                    with handle.extractfile(member) as stream:
                        members[member.name] = hashlib.file_digest(stream, "sha256").hexdigest()
    for name, digest in plan.get("source_sha256", {}).items():
        checks.check(members.get(name) == digest, f"production archived planned source: {name}")
    for name, expected in (
        ("config/default.yaml", plan.get("config_sha256")),
        ("config/external_validation.yaml", plan.get("settings_sha256")),
        ("uv.lock", plan.get("lock_sha256")),
    ):
        checks.check(members.get(name) == expected, f"archived config/lock binding: {name}")
    lock = tomllib.loads((root / "uv.lock").read_text())

    def normalize(name):
        return name.lower().replace("_", "-").replace(".", "-")

    versions = {
        normalize(name): version for name, version in manifest.get("package_versions", {}).items()
    }
    locked_versions = {}
    for package in lock["package"]:
        locked_versions.setdefault(normalize(package["name"]), set()).add(package["version"])
    for name, allowed in locked_versions.items():
        if name in versions:
            checks.check(versions[name] in allowed, f"locked production package: {name}")
    return {
        "manifest": str(path),
        "slurm_job_id": manifest["slurm_job_id"],
        "git_sha": manifest["git_sha"],
        "git_dirty": manifest["git_dirty"],
        "source_archive": str(archive),
        "source_sha256": manifest["source_sha256"],
    }


def audit(root):
    checks = Checks()
    default = yaml.safe_load((root / "config/default.yaml").read_text())
    settings = yaml.safe_load((root / "config/external_validation.yaml").read_text())
    cfg, shift_cfg = settings["external_validation"], settings["distribution_shift"]
    directory = root / default["paths"]["outputs"] / "external_validation"
    documents = {name: checks.read(directory / name) for name in RESULT_FILES}
    plan, state = documents["plan.json"], documents["preparation.json"]
    producing = provenance(checks, root, directory, plan, state, settings, default, RESULT_FILES)
    checks.check(state.get("complete") is True, "common-feature preparation complete")
    expected_models = {f"{e}__{m}__{f}" for e in cfg["endpoints"] for m in MODELS for f in FEATURES}
    checks.check(set(state.get("models", {})) == expected_models, "twelve common-feature fits")
    checks.check(set(state.get("preprocessors", {})) == set(FEATURES), "two training preprocessors")
    checks.check(
        state.get("n_train") == 989 and state.get("n_cal") == 495,
        "original frozen training/calibration sizes",
    )
    gates = default["mcmc"]["diagnostics"]
    for name, model in state.get("models", {}).items():
        checks.check(
            name == f"{model['endpoint']}__{model['model']}__{model['feature_set']}",
            f"fit key identity: {name}",
        )
        for path, digest in model.get("artifacts_sha256", {}).items():
            checks.digest(path, digest, f"fit record artifact: {name}/{Path(path).name}")
        if model["model"] == "weibull":
            d = model["diagnostics"]
            checks.check(
                d.get("passed") is True and all(d.get("checks", {}).values()),
                f"Bayesian diagnostics passed: {name}",
            )
            checks.check(d.get("thresholds") == gates, f"Bayesian gates unchanged: {name}")
            for field, bound, upper in (
                ("max_rhat", gates["max_rhat"], True),
                ("min_ess_bulk", gates["min_ess_bulk"], False),
                ("min_ess_tail", gates["min_ess_tail"], False),
                ("divergences", gates["max_divergences"], True),
            ):
                checks.finite(
                    d.get(field),
                    f"Bayesian {field}: {name}",
                    0 if upper else bound,
                    bound if upper else None,
                )
    expected_ridge = {k for k in expected_models if "__cox__" in k}
    checks.check(set(state.get("ridge", {})) == expected_ridge, "four ridge bootstrap arms")
    for key, item in state.get("ridge", {}).items():
        d, replicates = item["diagnostics"], cfg["qin_bootstrap_replicates"]
        checks.check(
            d.get("bootstrap_requested")
            == d.get("bootstrap_attempted")
            == d.get("bootstrap_successful")
            == len(item.get("pivots", []))
            == replicates
            and d.get("bootstrap_failed") == 0,
            f"all ridge refits succeeded: {key}",
        )
        checks.check(
            d.get("original_bootstrap_parameter_match") is True
            and d.get("working_model_parameters", {}).get("alpha") == cfg["qin_ridge_alpha"],
            f"ridge estimator matched: {key}",
        )
        checks.check(
            all(
                isinstance(v, (float, int)) and math.isfinite(v) and 0 <= v <= 1
                for v in item.get("pivots", [])
            ),
            f"finite probability pivots: {key}",
        )
    expected_cells = cell_contracts(
        cfg["endpoints"], cfg["alphas"], cfg["interval_horizons_months"]
    )
    checks.check(
        set(state.get("calibration", {}))
        == {k for k in expected_cells if not k.endswith("qin_bootstrap_ridge_cox")},
        "144 conservative calibration settings",
    )
    cohort, performance, coverage = (
        documents["cohort_audit.json"],
        documents["performance.json"],
        documents["coverage.json"],
    )
    checks.check(set(performance) == set(cfg["endpoints"]), "both external endpoints evaluated")
    checks.check(set(coverage) == set(expected_cells), "168 external interval cells")
    for endpoint, result in performance.items():
        n = cohort["endpoints"][endpoint]["analysis_patients"]
        performance_report(checks, result, endpoint, cfg, n)
        checks.check(
            result.get("n_target_events") == cohort["outcome_summaries"][endpoint]["events"],
            f"{endpoint}: event aggregate consistency",
        )
        if cfg["complete_predictor_sensitivity"]:
            performance_report(
                checks,
                result.get("complete_predictor_sensitivity", {}),
                endpoint + "/complete",
                cfg,
                cohort["outcome_summaries"][endpoint]["n_complete_common_predictors"],
            )
    for key, cell in coverage.items():
        if key not in expected_cells:
            continue
        contract = expected_cells[key]
        checks.check(
            all(cell.get(k) == v for k, v in contract.items()), f"external interval contract: {key}"
        )
        n_cal = (
            cfg["qin_bootstrap_replicates"]
            if contract["method"] == "qin_bootstrap_ridge_cox"
            else state["n_cal"]
        )
        n = cohort["endpoints"][contract["endpoint"]]["analysis_patients"]
        coverage_row(checks, cell["marginal"], key, contract, cfg, n_cal, n)
        for field, groups in cell.get("subgroups", {}).items():
            for level, row in groups.items():
                if row.get("status") == "suppressed_small_group":
                    checks.check(
                        set(row) == {"status"}, f"small subgroup suppressed: {key}/{field}/{level}"
                    )
                else:
                    checks.check(
                        row.get("n_target", 0) >= cfg["minimum_group_size"],
                        f"subgroup large enough: {key}/{field}/{level}",
                    )
                    coverage_row(checks, row, f"{key}/{field}/{level}", contract, cfg, n_cal)
    shifted = documents["distribution_shift.json"]
    shift_cells = cell_contracts(
        cfg["endpoints"], shift_cfg["alphas"], shift_cfg["horizons_months"]
    )
    checks.check(
        set(shifted.get("results", {})) == set(shift_cells), "168 original-model shift cells"
    )
    checks.check(
        shifted.get("status") == "post_hoc_test_reuse"
        and shifted.get("coverage_guarantee_under_shift") is False,
        "shift interpretation caveat",
    )
    checks.check(
        shifted.get("scenarios") == shift_cfg["scenarios"]
        and shifted.get("n_original_test") == 495,
        "fixed shift settings and original test size",
    )
    original = checks.read(directory.parent / "metrics/conformal_coverage.json")
    old_reliability = checks.read(directory.parent / "uncertainty_reliability/coverage.json")
    for key, cell in shifted.get("results", {}).items():
        if key not in shift_cells:
            continue
        contract = shift_cells[key]
        checks.check(
            all(cell.get(k) == v for k, v in contract.items()), f"shift interval contract: {key}"
        )
        checks.check(
            set(cell.get("scenarios", {})) == set(shift_cfg["scenarios"]),
            f"all four shift scenarios: {key}",
        )
        for name, row in cell.get("scenarios", {}).items():
            label = f"shift/{key}/{name}"
            checks.check(
                row.get("n_test") == 495 and row.get("bootstrap_stratified") is True,
                f"{label}: fixed test bootstrap",
            )
            expected_ncal = 1000 if contract["method"] == "qin_bootstrap_ridge_cox" else 495
            checks.check(
                row.get("n_cal") == expected_ncal and row.get("method") == contract["method"],
                f"{label}: method/calibration tag",
            )
            checks.finite(row.get("effective_sample_size"), f"{label}: ESS", 1, 495)
            checks.finite(row.get("maximum_normalized_weight"), f"{label}: max weight", 1 / 495, 1)
            if name == "baseline":
                checks.check(
                    math.isclose(row.get("effective_sample_size", 0), 495), f"{label}: uniform ESS"
                )
                checks.check(
                    math.isclose(row.get("weight_ratio_max_to_min", 0), 1),
                    f"{label}: uniform weight ratio",
                )
                old = (original.get(key) or old_reliability.get(key) or {}).get("marginal", {})
                for new_field, old_field in (
                    ("coverage_lower_bound", "observable_coverage_lower"),
                    ("coverage_upper_bound", "observable_coverage_upper"),
                    ("median_width", "width_median_months"),
                ):
                    checks.check(
                        old_field in old
                        and math.isclose(
                            row["estimates"][new_field]["estimate"],
                            old[old_field],
                            rel_tol=1e-9,
                            abs_tol=1e-9,
                        ),
                        f"{label}: reproduces frozen {old_field}",
                    )
            for statistic, value in row.get("estimates", {}).items():
                hi = contract["horizon_months"] if "width" in statistic else 1
                summary(checks, value, f"{label}/{statistic}", shift_cfg, lower=0, upper=hi)
            estimates = row["estimates"]
            checks.check(
                estimates["coverage_lower_bound"]["estimate"]
                <= estimates["coverage_upper_bound"]["estimate"],
                f"{label}: ordered coverage bounds",
            )
    return {
        "schema_version": 1,
        "status": "passed" if not checks.failures else "failed",
        "checks": checks.count,
        "failures": checks.failures,
        "failure_count": len(checks.failures),
        "metric_status_counts": dict(checks.metric_statuses),
        "producing_run": producing,
        "audited_artifacts_sha256": checks.checked_hashes,
        "audit_slurm_job_id": os.environ.get("SLURM_JOB_ID"),
        "audited_at_utc": datetime.now(UTC).isoformat(),
        "audit_source_sha256": sha256_file(Path(__file__)),
        "scope": (
            "Independent aggregate integrity and contract checks; "
            "no patient tables or model objects decoded; no numerical reproduction"
        ),
        "n_cal_interpretation": (
            "Conservative methods: 495 calibration patients; "
            "Qin: 1000 bootstrap pivots, not calibration patients"
        ),
        "limitations": [
            "Archived dirty-source execution is not clean-commit numerical reproduction",
            "Integrity checks do not establish clinical utility or transport coverage guarantees",
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output", type=Path, default=PROJECT_ROOT / "outputs/external_validation/audit.json"
    )
    args = parser.parse_args()
    require_compute_node("independent external-validation aggregate audit")
    try:
        result = audit(PROJECT_ROOT)
    except (KeyError, TypeError, ValueError, OSError) as error:
        result = {
            "status": "failed",
            "failure_count": 1,
            "failures": [
                f"Malformed aggregate contract prevented audit completion: {type(error).__name__}"
            ],
            "audit_slurm_job_id": os.environ.get("SLURM_JOB_ID"),
        }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(
        f"Independent external audit: {result['status']}; "
        f"{result.get('checks', 0)} checks, {result['failure_count']} failures; {args.output}"
    )
    raise SystemExit(0 if result["status"] == "passed" else 1)


if __name__ == "__main__":
    main()
