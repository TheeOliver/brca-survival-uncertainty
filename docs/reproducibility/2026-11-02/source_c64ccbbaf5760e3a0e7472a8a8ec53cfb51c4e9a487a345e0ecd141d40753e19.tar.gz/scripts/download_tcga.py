"""Download two public TCGA clinical sources; network I/O only, safe on login nodes.

An existing snapshot is verified and reused. It is never overwritten. Raw data
and endpoint/patient rows remain gitignored; only schema/provenance are logged.
"""

from __future__ import annotations

import argparse
from pathlib import Path

from brca.config import PROJECT_ROOT, load_config
from brca.data.cbioportal import fetch_study, save_raw, update_checksum_file
from brca.data.tcga import (
    LEGACY_STUDY_ID,
    PANCAN_STUDY_ID,
    load_tcga_snapshot,
    validate_tcga_payloads,
)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(PROJECT_ROOT / "config/external_validation.yaml"))
    args = parser.parse_args()
    cfg = load_config(args.config)
    raw_root = PROJECT_ROOT / cfg.paths.raw
    specs = cfg.external_validation.sources
    payloads, paths, reused = {}, {}, {}
    for name, expected in (("pancan", PANCAN_STUDY_ID), ("legacy", LEGACY_STUDY_ID)):
        spec = getattr(specs, name)
        if spec.study_id != expected:
            raise ValueError("TCGA source study differs from the declared acquisition protocol.")
        subdir = Path(spec.raw_subdir)
        if subdir.is_absolute() or ".." in subdir.parts:
            raise ValueError("TCGA raw subdirectory must lie below the configured raw root.")
        paths[name] = raw_root / subdir
        reused[name] = paths[name].exists()
        payloads[name] = (
            load_tcga_snapshot(paths[name], expected) if reused[name] else fetch_study(expected)
        )
    validate_tcga_payloads(payloads["pancan"], payloads["legacy"])
    for name in ("pancan", "legacy"):
        if not reused[name]:
            checksums = save_raw(payloads[name], paths[name])
            update_checksum_file(
                raw_root / "CHECKSUMS.sha256", checksums, str(getattr(specs, name).raw_subdir)
            )
        state = "verified existing" if reused[name] else "saved immutable"
        print(f"{name}: {state} public clinical snapshot")


if __name__ == "__main__":
    main()
