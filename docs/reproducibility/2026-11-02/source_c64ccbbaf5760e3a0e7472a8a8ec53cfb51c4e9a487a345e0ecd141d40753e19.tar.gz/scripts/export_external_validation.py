"""Export stored TCGA validation and distribution-shift aggregates on SLURM."""

import argparse
import json

from brca.compute_guard import require_compute_node
from brca.config import DEFAULT_CONFIG_PATH, PROJECT_ROOT
from brca.manifest import sha256_file
from brca.pipeline import StageRun, write_json
from brca.viz.external import render_external_validation


def validated_external_inputs(run):
    """Require a successful evaluation manifest covering every aggregate input."""
    directory = run.outputs / "external_validation"
    paths = {
        name: directory / f"{name}.json"
        for name in (
            "plan",
            "preparation",
            "cohort_audit",
            "covariate_shift",
            "performance",
            "coverage",
            "distribution_shift",
        )
    }
    inputs = {name: json.loads(path.read_text()) for name, path in paths.items()}
    plan = inputs["plan"]
    if plan["config_sha256"] != run.metadata["config_sha256"]:
        raise ValueError("Export configuration differs from the frozen external protocol")
    if not inputs["preparation"].get("complete"):
        raise ValueError("External model preparation is incomplete")
    if inputs["preparation"]["plan_sha256"] != sha256_file(paths["plan"]):
        raise ValueError("Prepared models do not belong to the frozen external plan")
    for relative, digest in plan["source_sha256"].items():
        if sha256_file(PROJECT_ROOT / relative) != digest:
            raise ValueError(f"Statistical source changed since evaluation: {relative}")
    hashes = {str(path): sha256_file(path) for path in paths.values()}
    for candidate in sorted(
        (run.outputs / "manifests").glob("05_external_validation_*.json"), reverse=True
    ):
        manifest = json.loads(candidate.read_text())
        if (
            manifest.get("status") == "exploratory_external_and_shift_complete"
            and manifest["config_sha256"] == plan["config_sha256"]
            and all(
                manifest["artifacts_sha256"].get(path) == digest for path, digest in hashes.items()
            )
            and sha256_file(manifest["source_archive"]) == manifest["source_sha256"]
        ):
            return inputs, paths, candidate
    raise ValueError("External aggregates lack a successful matching evaluation manifest")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", default=str(DEFAULT_CONFIG_PATH))
    parser.add_argument("--allow-dirty", action="store_true")
    args = parser.parse_args()
    require_compute_node("external-validation export")
    run = StageRun("06_export_external_validation", args.config, allow_dirty=args.allow_dirty)
    inputs, paths, evaluation_manifest = validated_external_inputs(run)
    hashes = {str(path): sha256_file(path) for path in paths.values()}
    directory = run.outputs / "external_validation"
    artifacts = render_external_validation(inputs, directory, run.config)
    if any(sha256_file(path) != digest for path, digest in hashes.items()):
        raise ValueError("An aggregate input changed during export")
    metadata = directory / "export_metadata.json"
    write_json(
        metadata,
        {
            "status": "exploratory_external_and_post_hoc_internal_shift",
            "statistics_recomputed": False,
            "input_artifacts_sha256": hashes,
            "evaluation_manifest": str(evaluation_manifest),
            "evaluation_manifest_sha256": sha256_file(evaluation_manifest),
            "export_source_sha256": run.metadata["source_sha256"],
            "export_source_archive": run.metadata["source_archive"],
            "artifacts_sha256": {str(path): sha256_file(path) for path in artifacts},
            "external_report_endpoint": inputs["plan"]["settings"]["external_validation"][
                "primary_external_endpoint"
            ],
            "external_report_alpha": inputs["plan"]["settings"]["external_validation"][
                "report_alpha"
            ],
            "shift_fixed_display_model": "disease_specific__cox__clinical_molecular",
        },
    )
    run.finish(
        [*artifacts, metadata],
        status="complete",
        input_artifacts_sha256=hashes,
        evaluation_manifest_sha256=sha256_file(evaluation_manifest),
    )
    print(f"Exported {len(artifacts)} external-validation artifacts and provenance metadata.")


if __name__ == "__main__":
    main()
