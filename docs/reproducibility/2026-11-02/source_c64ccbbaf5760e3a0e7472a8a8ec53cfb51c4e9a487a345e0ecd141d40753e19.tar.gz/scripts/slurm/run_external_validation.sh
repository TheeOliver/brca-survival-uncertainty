#!/bin/bash
# Isolated METABRIC distribution shift and TCGA common-feature validation.
#SBATCH --job-name=brca-external
#SBATCH --partition=openlab-queue
#SBATCH --cpus-per-task=4
#SBATCH --mem=12G
#SBATCH --time=04:00:00
#SBATCH --output=logs/slurm-%j.out

set -euo pipefail
cd "${SLURM_SUBMIT_DIR:-$PWD}"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
make check
uv run python scripts/05_evaluate.py --external-validation --allow-dirty "$@"
